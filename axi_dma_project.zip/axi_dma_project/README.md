# Deterministic AXI-based DMA Controller with Bandwidth Reservation and WCET Analysis

Verilog-2005 RTL (plus a SystemVerilog testbench), Icarus/xsim simulation, Vivado out-of-context implementation flow, and Python analysis. Everything below was written and run end to end in Icarus Verilog 12 except the Vivado/xsim scripts (see section 8).

## 1. Files

```
rtl/axi_dma_top.v      top: AXI4-Lite slave + 4 channels + scheduler + shared AXI4 master mux
rtl/axi_dma_regs.v     AXI4-Lite register file (descriptors, start/loop/stop, status, perf counters, slot table)
rtl/axi_dma_ch.v       DMA channel: read burst -> local buffer -> write burst, loop mode, HW latency counters
rtl/dma_sched.v        MODE 0 = TDMA slot table (reservation), MODE 1 = round-robin, MODE 2 = fixed priority
rtl/axi_mem_model.v    AXI4 slave memory, fixed latency + bounded LFSR jitter (simulation only)
tb/tb_axi_dma.sv       self-checking testbench (prints machine-readable lines)
scripts/analyze.py     parses logs -> results/summary.md, CSVs, 3 PNG figures, exact WCET enumeration
scripts/parse_vivado.py  Vivado reports -> results/vivado_summary.md
scripts/make_single_file.py  builds eda_playground/design.sv + testbench.sv for online simulators
sim/run_icarus.sh      runs 3 schedulers + a zero-jitter TDMA run
sim/run_xsim.bat|.sh   same runs with Vivado xsim
vivado/run_impl.tcl    synth + place + route + reports, one scheduler mode per call
vivado/run_all_impl.bat|.sh   runs modes 0,1,2 and builds the comparison table
constraints/axi_dma.xdc       100 MHz clock + I/O delays
results/               output of my run (simulation numbers, figures)
```

## 2. How the design is deterministic

- Fixed burst: INCR, 16 beats x 32 bit = 64 bytes, aligned (no 4 KB crossing). One transaction in flight on the shared master port.
- A grant is exclusive and non-preemptive. A channel finishes `AR/R` then `AW/W/B` for one burst while it holds the grant.
- TDMA: a frame of `S_SLOTS`=8 slots, each `SLOT_LEN`=64 cycles. The slot table (runtime programmable, registers 0x400+) says which channel owns each slot. Default `[0,1,0,2,0,1,0,3]` = 50 / 25 / 12.5 / 12.5 %. The owner's request is sampled at the slot boundary; unused slot time is not given away. This is what makes latency independent of other masters.
- If a burst ever outlasts its slot (slave slower than assumed), the slot counter stalls, the sticky `overrun` bit sets (STATUS[31]) and the testbench flags it.

## 3. Register map (AXI4-Lite, 12-bit address)

| Addr | Name | Notes |
|---|---|---|
| 0x000 | CTRL | bit0 clear status, bit1 clear perf counters |
| 0x004 | STATUS | [3:0] done (sticky), [11:8] busy, [19:16] error, [31] slot overrun |
| 0x008 | INFO | {0, BURST_LEN, S_SLOTS, N_CH} |
| 0x00C | SLOT_LEN | cycles |
| 0x100 + 0x40*c | SRC, +4 DST, +8 NBURSTS | addresses forced to 64 B alignment |
| +0x0C | START | bit0 start, bit1 loop (auto-restart), bit2 stop loop |
| +0x10 / 0x14 / 0x18 / 0x1C | DESC_LAT_LAST, DESC_LAT_MAX, BURST_LAT_MAX, BURSTS_DONE | HW counters (cycles) |
| 0x400 + 4*s | SLOT_TBL[s] | owner channel id |

## 4. Run the simulation

Local (Linux, WSL, macOS with Icarus Verilog >= 11):

```
./run_all.sh            # simulate 4 runs (~2 min), then analysis + figures
```

Single run, for example TDMA only:

```
iverilog -g2012 -DMODE_VAL=0 -DJIT_VAL=4 -s tb_axi_dma -o m0.vvp rtl/*.v tb/tb_axi_dma.sv
vvp -n m0.vvp | grep -E "^(CHECK|SUMMARY)"
```

Add `-DWAVE` to dump `dma_wave.vcd` (first 6000 cycles) for GTKWave or for annotated waveform screenshots.

Online (EDA Playground or similar): run `python3 scripts/make_single_file.py`, paste `eda_playground/design.sv` into the design pane and `eda_playground/testbench.sv` into the testbench pane, pick Icarus Verilog (SystemVerilog enabled) and run. Change `MODE_VAL` at the top of the testbench (0, 1, 2) for each scheduler. The reduced sweep sizes are there to keep run time short. Save the console output of each run as `sim/logs/mode0.log`, `mode1.log`, `mode2.log` (and `mode0_jit0.log` with `JIT_VAL=0`) and `python3 scripts/analyze.py` produces the same tables and figures.

Vivado xsim: `sim\run_xsim.bat` (Windows, from a Vivado command prompt) or `sim/run_xsim.sh`. It writes the same log names, then runs the analysis.

## 5. Vivado implementation (timing, utilization, power)

```
set PART=xc7z020clg400-1      (use your board's part)
set CLK_NS=10.0               (target period; try 5.0 for a stress run)
vivado\run_all_impl.bat
```

This runs synth, place, route per scheduler mode in out-of-context mode (so no pin assignment is needed), and writes `build/modeN/timing_summary.rpt`, `utilization.rpt`, `power.rpt`, `drc.rpt`, `methodology.rpt` plus `results/vivado_summary.md`. For the presentation, open `build/modeN/post_route.dcp` in Vivado and take the Timing Summary and Utilization screenshots from there.

## 6. WCET analysis

Worst-case burst service, from the FSM timing (grant visible -> release cycle):

`R_REL_MAX = RD_LAT + WR_LAT + 2*BURST_LEN + 3 + 2*JITTER` = 55 cycles for the defaults (47 with zero jitter).

For a descriptor of n bursts on channel c, a request made at start cycle t0 becomes eligible at slot boundaries >= t0+2; burst k starts at the first owned slot start after the previous release + 2, and release is at start + R_REL_MAX. `scripts/analyze.py` enumerates every t0 in the frame and takes the maximum (exact). A closed form is also checked in the testbench: `ceil(n/slots_c)*FRAME + R_REL_MAX + 2`.

Validity condition: `SLOT_LEN >= RD_LAT + WR_LAT + 2*BURST_LEN + 5 + 2*JITTER` (57 for the defaults; 64 used). If you change latency or burst length, change `SLOT_LEN` first. I verified that an undersized slot (48) trips the overrun and bound checks.

Validation: with zero jitter the full 512-phase sweep for ch3 measures 561 cycles and the analytic value is 561.

## 7. What the testbench checks

Register map, default slot table, 4-channel concurrent copy with data compare, HW counters, no error/overrun, AXI burst rules (alignment, 4 KB, length, LAST position, one-hot grant), TDMA bandwidth split, victim latency sweep idle vs loaded, per-channel WCET bound for n=1 and n=4, bus-hold time within the slot.

## 8. Limits and things I could not verify

- Vivado and xsim are not available where this was built. `vivado/run_impl.tcl` and the xsim scripts are untested; expect to fix small syntax or option issues on the first run. All simulation results come from Icarus Verilog 12.
- No timing, area or power number from Vivado is included. Do not quote any until you have run the flow; the placeholders in `results/vivado_summary.md` are generated from your reports.
- The WCET bound is valid only for a slave whose read/write latency stays within `RD_LAT/WR_LAT + JITTER`. A real DDR controller (refresh, bank conflicts) needs its own worst-case latency figures, or use on-chip BRAM as the target.
- Simplifications: register-programmed descriptors only (no scatter-gather in memory), 32-bit data, read-then-write per burst (about 1.0 B/cycle copy rate with TDMA at the default settings), no IRQ masking, no AXI IDs beyond the channel number, no outstanding-transaction pipelining.
- The round-robin latency bound (`~234 cycles`) is my own derivation, checked only against simulation.
- I have not added literature citations because I cannot verify exact titles from here; for related work search IEEE Xplore / ACM DL for "predictable DMA", "TDMA memory arbitration", "AXI bandwidth regulation" and cite what you actually read.
