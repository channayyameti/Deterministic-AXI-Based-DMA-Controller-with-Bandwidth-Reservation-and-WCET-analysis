@echo off
cd /d %~dp0\..
for %%M in (0 1 2) do (
  vivado -mode batch -nojournal -nolog -source vivado\run_impl.tcl -tclargs %%M
)
python scripts\parse_vivado.py
