set root   [file normalize [file join [file dirname [info script]] ..]]
set mode   [expr {[llength $argv] > 0 ? [lindex $argv 0] : 0}]
set part   [expr {[info exists ::env(PART)]   ? $::env(PART)   : "xc7z020clg400-1"}]
set period [expr {[info exists ::env(CLK_NS)] ? $::env(CLK_NS) : 10.0}]
set outdir [file join $root build mode$mode]
file mkdir $outdir

set fh [open [file join $outdir clk.xdc] w]
puts $fh "create_clock -period $period -name clk \[get_ports clk\]"
puts $fh "set_input_delay  -clock clk -max 2.000 \[remove_from_collection \[all_inputs\] \[get_ports clk\]\]"
puts $fh "set_input_delay  -clock clk -min 0.500 \[remove_from_collection \[all_inputs\] \[get_ports clk\]\]"
puts $fh "set_output_delay -clock clk -max 2.000 \[all_outputs\]"
puts $fh "set_output_delay -clock clk -min 0.000 \[all_outputs\]"
close $fh

read_verilog [list \
    [file join $root rtl axi_dma_ch.v] \
    [file join $root rtl dma_sched.v] \
    [file join $root rtl axi_dma_regs.v] \
    [file join $root rtl axi_dma_top.v]]
read_xdc [file join $outdir clk.xdc]

synth_design -top axi_dma_top -part $part -mode out_of_context -generic MODE=$mode
write_checkpoint -force [file join $outdir post_synth.dcp]
report_utilization -file [file join $outdir utilization_synth.rpt]

opt_design
place_design
phys_opt_design
route_design

write_checkpoint -force [file join $outdir post_route.dcp]
report_timing_summary -delay_type min_max -max_paths 10 -report_unconstrained -file [file join $outdir timing_summary.rpt]
report_timing -delay_type max -max_paths 5 -sort_by slack -file [file join $outdir timing_worst_setup.rpt]
report_utilization -file [file join $outdir utilization.rpt]
report_power -file [file join $outdir power.rpt]
report_clock_interaction -file [file join $outdir clock_interaction.rpt]
report_drc -file [file join $outdir drc.rpt]
report_methodology -file [file join $outdir methodology.rpt]

set wns [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]]
set whs [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -hold]]
set sf [open [file join $outdir summary.csv] w]
puts $sf "mode,part,period_ns,wns_ns,whs_ns"
puts $sf "$mode,$part,$period,$wns,$whs"
close $sf
puts "DONE mode=$mode part=$part period=$period WNS=$wns WHS=$whs"
