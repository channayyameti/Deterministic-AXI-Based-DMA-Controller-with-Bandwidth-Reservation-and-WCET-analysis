#!/bin/sh
cd "$(dirname "$0")/.."
for M in 0 1 2; do
  vivado -mode batch -nojournal -nolog -source vivado/run_impl.tcl -tclargs $M
done
python3 scripts/parse_vivado.py
