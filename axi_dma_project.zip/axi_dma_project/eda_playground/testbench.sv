`timescale 1ns/1ps

`ifndef MODE_VAL
`define MODE_VAL 0
`endif
`ifndef JIT_VAL
`define JIT_VAL 4
`endif
`ifndef SWEEP_N
`define SWEEP_N 128
`endif
`ifndef BW_WIN
`define BW_WIN 8000
`endif
`ifndef T4_N
`define T4_N 16
`endif

module tb_axi_dma;
    localparam N_CH      = 4;
    localparam S_SLOTS   = 8;
    localparam SLOT_LEN  = 64;
    localparam BURST_LEN = 16;
    localparam DATA_W    = 32;
    localparam ADDR_W    = 32;
    localparam OWN_W     = 2;
    localparam MODE      = `MODE_VAL;
    localparam JIT       = `JIT_VAL;
    localparam RD_LAT    = 8;
    localparam WR_LAT    = 4;
    localparam FRAME     = S_SLOTS * SLOT_LEN;
    localparam R_REL_MAX = RD_LAT + WR_LAT + 2*BURST_LEN + 3 + 2*JIT;
    localparam C_SLOT    = R_REL_MAX + 1;
    localparam SWEEP_N   = `SWEEP_N;
    localparam BW_WIN    = `BW_WIN;
    localparam T4_N      = `T4_N;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #5 clk = ~clk;

    reg  [11:0] s_axil_awaddr  = 0;
    reg         s_axil_awvalid = 0;
    wire        s_axil_awready;
    reg  [31:0] s_axil_wdata   = 0;
    reg  [3:0]  s_axil_wstrb   = 4'hF;
    reg         s_axil_wvalid  = 0;
    wire        s_axil_wready;
    wire [1:0]  s_axil_bresp;
    wire        s_axil_bvalid;
    reg         s_axil_bready  = 1;
    reg  [11:0] s_axil_araddr  = 0;
    reg         s_axil_arvalid = 0;
    wire        s_axil_arready;
    wire [31:0] s_axil_rdata;
    wire [1:0]  s_axil_rresp;
    wire        s_axil_rvalid;
    reg         s_axil_rready  = 1;

    wire [OWN_W-1:0]   m_axi_arid;
    wire [ADDR_W-1:0]  m_axi_araddr;
    wire [7:0]         m_axi_arlen;
    wire [2:0]         m_axi_arsize;
    wire [1:0]         m_axi_arburst;
    wire               m_axi_arlock;
    wire [3:0]         m_axi_arcache;
    wire [2:0]         m_axi_arprot;
    wire [3:0]         m_axi_arqos;
    wire               m_axi_arvalid;
    wire               m_axi_arready;
    wire [DATA_W-1:0]  m_axi_rdata;
    wire [1:0]         m_axi_rresp;
    wire               m_axi_rlast;
    wire               m_axi_rvalid;
    wire               m_axi_rready;
    wire [OWN_W-1:0]   m_axi_awid;
    wire [ADDR_W-1:0]  m_axi_awaddr;
    wire [7:0]         m_axi_awlen;
    wire [2:0]         m_axi_awsize;
    wire [1:0]         m_axi_awburst;
    wire               m_axi_awlock;
    wire [3:0]         m_axi_awcache;
    wire [2:0]         m_axi_awprot;
    wire [3:0]         m_axi_awqos;
    wire               m_axi_awvalid;
    wire               m_axi_awready;
    wire [DATA_W-1:0]  m_axi_wdata;
    wire [DATA_W/8-1:0] m_axi_wstrb;
    wire               m_axi_wlast;
    wire               m_axi_wvalid;
    wire               m_axi_wready;
    wire [1:0]         m_axi_bresp;
    wire               m_axi_bvalid;
    wire               m_axi_bready;

    wire               irq;
    wire [N_CH-1:0]    dbg_start;
    wire [N_CH-1:0]    dbg_done;
    wire [N_CH-1:0]    dbg_gnt;
    wire [N_CH-1:0]    dbg_req;
    wire               dbg_overrun;
    wire [$clog2(S_SLOTS)-1:0] dbg_slot;

    axi_dma_top #(
        .N_CH(N_CH), .S_SLOTS(S_SLOTS), .SLOT_LEN(SLOT_LEN), .MODE(MODE),
        .DATA_W(DATA_W), .ADDR_W(ADDR_W), .BURST_LEN(BURST_LEN), .OWN_W(OWN_W)
    ) u_dut (.*);

    axi_mem_model #(
        .ADDR_W(ADDR_W), .DATA_W(DATA_W), .MEM_WORDS(32768),
        .RD_LAT(RD_LAT), .WR_LAT(WR_LAT), .JITTER(JIT)
    ) u_mem (
        .clk(clk), .rst_n(rst_n),
        .araddr(m_axi_araddr), .arlen(m_axi_arlen), .arvalid(m_axi_arvalid), .arready(m_axi_arready),
        .rdata(m_axi_rdata), .rresp(m_axi_rresp), .rlast(m_axi_rlast), .rvalid(m_axi_rvalid), .rready(m_axi_rready),
        .awaddr(m_axi_awaddr), .awlen(m_axi_awlen), .awvalid(m_axi_awvalid), .awready(m_axi_awready),
        .wdata(m_axi_wdata), .wlast(m_axi_wlast), .wvalid(m_axi_wvalid), .wready(m_axi_wready),
        .bresp(m_axi_bresp), .bvalid(m_axi_bvalid), .bready(m_axi_bready)
    );

    integer cyc = 0;
    always @(posedge clk) cyc <= cyc + 1;

    integer t_start [0:N_CH-1];
    integer t_done  [0:N_CH-1];
    integer done_cnt [0:N_CH-1];
    integer burst_total [0:N_CH-1];
    integer hold [0:N_CH-1];
    integer gnt_cycles = 0;
    integer svc_min = 1000000;
    integer svc_max = 0;
    integer proto_err = 0;
    integer rbeat = 0;
    integer wbeat = 0;
    reg [N_CH-1:0] gnt_q = 0;
    integer own_cnt [0:N_CH-1];
    integer tbl_def [0:S_SLOTS-1];
    integer pass_n = 0;
    integer fail_n = 0;

    integer mi;
    initial begin
        for (mi = 0; mi < N_CH; mi = mi + 1) begin
            t_start[mi] = 0; t_done[mi] = 0; done_cnt[mi] = 0; burst_total[mi] = 0; hold[mi] = 0;
        end
        tbl_def[0] = 0; tbl_def[1] = 1; tbl_def[2] = 0; tbl_def[3] = 2;
        tbl_def[4] = 0; tbl_def[5] = 1; tbl_def[6] = 0; tbl_def[7] = 3;
        own_cnt[0] = 4; own_cnt[1] = 2; own_cnt[2] = 1; own_cnt[3] = 1;
    end

    integer mon_i;
    always @(posedge clk) begin
        gnt_q <= dbg_gnt;
        for (mon_i = 0; mon_i < N_CH; mon_i = mon_i + 1) begin
            if (dbg_start[mon_i]) t_start[mon_i] = cyc;
            if (dbg_done[mon_i]) begin t_done[mon_i] = cyc; done_cnt[mon_i] = done_cnt[mon_i] + 1; end
            if (dbg_gnt[mon_i] && !gnt_q[mon_i]) burst_total[mon_i] = burst_total[mon_i] + 1;
            if (dbg_gnt[mon_i]) hold[mon_i] = hold[mon_i] + 1;
            else if (hold[mon_i] != 0) begin
                if (hold[mon_i] > svc_max) svc_max = hold[mon_i];
                if (hold[mon_i] < svc_min) svc_min = hold[mon_i];
                hold[mon_i] = 0;
            end
        end
        if (|dbg_gnt) gnt_cycles = gnt_cycles + 1;
    end

    always @(posedge clk) if (rst_n) begin
        if (m_axi_arvalid && m_axi_arready) begin
            if (m_axi_araddr[5:0] != 0 || (m_axi_araddr[11:0] + 64) > 4096) proto_err = proto_err + 1;
            if (m_axi_arlen != BURST_LEN-1 || m_axi_arburst != 2'b01) proto_err = proto_err + 1;
        end
        if (m_axi_awvalid && m_axi_awready) begin
            if (m_axi_awaddr[5:0] != 0 || (m_axi_awaddr[11:0] + 64) > 4096) proto_err = proto_err + 1;
            if (m_axi_awlen != BURST_LEN-1 || m_axi_awburst != 2'b01) proto_err = proto_err + 1;
        end
        if (m_axi_rvalid && m_axi_rready) begin
            rbeat = rbeat + 1;
            if (m_axi_rlast != (rbeat == BURST_LEN)) proto_err = proto_err + 1;
            if (m_axi_rlast) rbeat = 0;
        end
        if (m_axi_wvalid && m_axi_wready) begin
            wbeat = wbeat + 1;
            if (m_axi_wlast != (wbeat == BURST_LEN)) proto_err = proto_err + 1;
            if (m_axi_wlast) wbeat = 0;
        end
        if ((dbg_gnt & (dbg_gnt - 1'b1)) != 0) proto_err = proto_err + 1;
    end

    task axil_write(input [11:0] a, input [31:0] d);
        begin
            s_axil_awaddr <= a; s_axil_wdata <= d;
            s_axil_awvalid <= 1'b1; s_axil_wvalid <= 1'b1;
            @(posedge clk);
            while (!(s_axil_awready && s_axil_wready)) @(posedge clk);
            s_axil_awvalid <= 1'b0; s_axil_wvalid <= 1'b0;
        end
    endtask

    task axil_read(input [11:0] a, output [31:0] d);
        begin
            s_axil_araddr <= a; s_axil_arvalid <= 1'b1;
            @(posedge clk);
            while (!s_axil_arready) @(posedge clk);
            s_axil_arvalid <= 1'b0;
            @(posedge clk);
            while (!s_axil_rvalid) @(posedge clk);
            d = s_axil_rdata;
        end
    endtask

    function [11:0] chreg(input integer c, input integer off);
        chreg = 12'h100 + c*12'h40 + off;
    endfunction

    function [31:0] src_of(input integer c);
        src_of = c * 32'h4000;
    endfunction

    function [31:0] dst_of(input integer c);
        dst_of = 32'h10000 + c * 32'h4000;
    endfunction

    function [31:0] pattern(input integer c, input integer w);
        pattern = (c << 28) ^ (w * 32'h9E3779B1) ^ 32'h5A5A1234;
    endfunction

    task cfg_ch(input integer c, input integer nb);
        begin
            axil_write(chreg(c, 0), src_of(c));
            axil_write(chreg(c, 4), dst_of(c));
            axil_write(chreg(c, 8), nb);
        end
    endtask

    task start_ch(input integer c, input integer lp);
        begin
            axil_write(chreg(c, 12), 32'h1 | (lp << 1));
        end
    endtask

    task stop_loop(input integer c);
        begin
            axil_write(chreg(c, 12), 32'h4);
        end
    endtask

    task wait_idle(input integer timeout);
        integer t;
        reg [31:0] r;
        begin
            t = 0;
            r = 32'h0000FF00;
            while (r[8 +: N_CH] != 0 && t < timeout) begin
                repeat (8) @(posedge clk);
                axil_read(12'h004, r);
                t = t + 12;
            end
            if (r[8 +: N_CH] != 0) $display("WARN,wait_idle_timeout,%0d", timeout);
        end
    endtask

    task check(input [255:0] name, input ok);
        begin
            if (ok) pass_n = pass_n + 1; else fail_n = fail_n + 1;
            $display("CHECK,%0s,%0s", name, ok ? "PASS" : "FAIL");
        end
    endtask

    function integer ceil_div(input integer a, input integer b);
        ceil_div = (a + b - 1) / b;
    endfunction

    function integer wcet_bound(input integer c, input integer nb);
        wcet_bound = ceil_div(nb, own_cnt[c]) * FRAME + R_REL_MAX + 2;
    endfunction

    task measure(input integer c, input integer timeout, output integer lat, output integer starved);
        integer dc0, t;
        begin
            dc0 = done_cnt[c];
            axil_write(chreg(c, 12), 32'h1);
            t = 0;
            while (done_cnt[c] == dc0 && t < timeout) begin
                @(posedge clk);
                t = t + 1;
            end
            if (done_cnt[c] == dc0) begin
                starved = 1; lat = 0;
            end else begin
                starved = 0; lat = t_done[c] - t_start[c];
            end
        end
    endtask

    task run_sweep(input integer c, input integer nb, input integer ns, input integer agg, input [7:0] tag, output integer max_o, output integer starved_o);
        integer k, lat, st, mn, mx, sm, cnt, a, gap, bound;
        begin
            for (a = 0; a < N_CH; a = a + 1)
                if (agg != 0 && a != c) begin cfg_ch(a, 16); start_ch(a, 1); end
            cfg_ch(c, nb);
            repeat (FRAME) @(posedge clk);
            mn = 1 << 30; mx = 0; sm = 0; cnt = 0; st = 0;
            k = 0;
            while (k < ns && st == 0) begin
                gap = 1 + ((k * 37) % FRAME);
                repeat (gap) @(posedge clk);
                measure(c, (nb + 3) * FRAME, lat, st);
                if (st == 0) begin
                    if (lat < mn) mn = lat;
                    if (lat > mx) mx = lat;
                    sm = sm + lat; cnt = cnt + 1;
                    $display("SAMP,%0d,%0s,%0d,%0d,%0d,%0d", MODE, tag, c, nb, k, lat);
                end
                k = k + 1;
            end
            if (cnt == 0) mn = 0;
            $display("LAT,%0d,%0s,%0d,%0d,%0d,%0d,%0d,%0d,%0d", MODE, tag, c, nb, cnt, mn, mx, sm, st);
            for (a = 0; a < N_CH; a = a + 1)
                if (agg != 0 && a != c) stop_loop(a);
            wait_idle(60000);
            max_o = mx; starved_o = st;
            if (MODE == 0 && agg != 0) begin
                bound = wcet_bound(c, nb);
                check("tdma_wcet_bound", (st == 0) && (mx <= bound));
                $display("BOUND,%0d,%0s,%0d,%0d,%0d,%0d", MODE, tag, c, nb, bound, mx);
            end
        end
    endtask

    integer c, w, mism, i;
    reg [31:0] rv;
    integer snap [0:N_CH-1];
    integer gsnap;
    integer maxA, maxB, stA, stB, mx_dummy, st_dummy;

    task bw_window(input [39:0] tag);
        integer a;
        begin
            for (a = 0; a < N_CH; a = a + 1) begin cfg_ch(a, 16); end
            for (a = 0; a < N_CH; a = a + 1) begin snap[a] = burst_total[a]; end
            gsnap = gnt_cycles;
            for (a = 0; a < N_CH; a = a + 1) start_ch(a, 1);
            repeat (BW_WIN) @(posedge clk);
            for (a = 0; a < N_CH; a = a + 1)
                $display("BW,%0s,%0d,%0d,%0d,%0d", tag, MODE, a, burst_total[a] - snap[a], BW_WIN);
            $display("UTIL,%0s,%0d,%0d,%0d", tag, MODE, gnt_cycles - gsnap, BW_WIN);
            for (a = 0; a < N_CH; a = a + 1) stop_loop(a);
            wait_idle(80000);
        end
    endtask

    initial begin
        $display("CFG,MODE,%0d", MODE);
        $display("CFG,JITTER,%0d", JIT);
        $display("CFG,N_CH,%0d", N_CH);
        $display("CFG,S_SLOTS,%0d", S_SLOTS);
        $display("CFG,SLOT_LEN,%0d", SLOT_LEN);
        $display("CFG,BURST_LEN,%0d", BURST_LEN);
        $display("CFG,DATA_W,%0d", DATA_W);
        $display("CFG,RD_LAT,%0d", RD_LAT);
        $display("CFG,WR_LAT,%0d", WR_LAT);
        $display("CFG,FRAME,%0d", FRAME);
        $display("CFG,R_REL_MAX,%0d", R_REL_MAX);
        $display("CFG,CLK_NS,10");

        for (c = 0; c < N_CH; c = c + 1)
            for (w = 0; w < 4096; w = w + 1) begin
                u_mem.mem[(src_of(c) >> 2) + w] = pattern(c, w);
                u_mem.mem[(dst_of(c) >> 2) + w] = 32'h0;
            end

        repeat (5) @(posedge clk);
        rst_n <= 1'b1;
        repeat (5) @(posedge clk);

        axil_read(12'h008, rv);
        check("info_reg", rv == {8'd0, 8'd16, 8'd8, 8'd4});
        axil_read(12'h00C, rv);
        check("slot_len_reg", rv == SLOT_LEN);
        mism = 0;
        for (i = 0; i < S_SLOTS; i = i + 1) begin
            axil_read(12'h400 + i*4, rv);
            if (rv != tbl_def[i]) mism = mism + 1;
        end
        check("default_slot_table", mism == 0);

        for (c = 0; c < N_CH; c = c + 1) cfg_ch(c, 8);
        for (c = 0; c < N_CH; c = c + 1) start_ch(c, 0);
        wait_idle(40000);
        mism = 0;
        for (c = 0; c < N_CH; c = c + 1)
            for (w = 0; w < 8*BURST_LEN; w = w + 1)
                if (u_mem.mem[(dst_of(c) >> 2) + w] !== pattern(c, w)) mism = mism + 1;
        $display("FUNC,%0d,%0d", MODE, mism);
        check("func_copy_all_channels", mism == 0);
        axil_read(12'h004, rv);
        check("status_done_no_err", rv[3:0] == 4'hF && rv[16 +: N_CH] == 0 && rv[31] == 1'b0);
        mism = 0;
        for (c = 0; c < N_CH; c = c + 1) begin
            axil_read(chreg(c, 28), rv);
            if (rv != 8) mism = mism + 1;
        end
        check("hw_burst_counters", mism == 0);
        axil_write(12'h000, 32'h3);

        bw_window("def");

        for (i = 0; i < S_SLOTS; i = i + 1) begin
            case (i)
                0: axil_write(12'h400 + i*4, 0);
                1: axil_write(12'h400 + i*4, 0);
                2: axil_write(12'h400 + i*4, 1);
                3: axil_write(12'h400 + i*4, 0);
                4: axil_write(12'h400 + i*4, 2);
                5: axil_write(12'h400 + i*4, 0);
                6: axil_write(12'h400 + i*4, 3);
                7: axil_write(12'h400 + i*4, 0);
            endcase
        end
        bw_window("alt");
        for (i = 0; i < S_SLOTS; i = i + 1) axil_write(12'h400 + i*4, tbl_def[i]);

        run_sweep(3, 1, SWEEP_N, 0, "A", maxA, stA);
        run_sweep(3, 1, SWEEP_N, 1, "B", maxB, stB);
        $display("ISO,%0d,%0d,%0d,%0d,%0d", MODE, maxA, stA, maxB, stB);
        if (MODE == 0) check("tdma_isolation", stA == 0 && stB == 0 &&
                             (maxA > maxB ? maxA - maxB : maxB - maxA) <= 2*JIT + 2);

        for (c = 0; c < N_CH; c = c + 1) begin
            run_sweep(c, 1, T4_N, 1, "C", mx_dummy, st_dummy);
            run_sweep(c, 4, T4_N, 1, "D", mx_dummy, st_dummy);
        end

        axil_read(12'h004, rv);
        $display("STATUS,%0d,%0h", MODE, rv);
        check("no_overrun", rv[31] == 1'b0 && dbg_overrun == 1'b0);
        check("axi_protocol", proto_err == 0);
        $display("SVC,%0d,%0d,%0d,%0d", MODE, svc_min, svc_max, C_SLOT);
        if (MODE == 0) check("svc_within_slot", svc_max <= C_SLOT && svc_max < SLOT_LEN);
        $display("SUMMARY,%0d,%0d,%0d,%0d", MODE, JIT, pass_n, fail_n);
        $display("SIM_DONE,%0d", cyc);
        $finish;
    end

    initial begin
        #1500000000;
        $display("FATAL,watchdog_timeout");
        $finish;
    end

`ifdef WAVE
    initial begin
        $dumpfile("dma_wave.vcd");
        $dumpvars(0, tb_axi_dma);
        #60000;
        $dumpoff;
    end
`endif
endmodule
