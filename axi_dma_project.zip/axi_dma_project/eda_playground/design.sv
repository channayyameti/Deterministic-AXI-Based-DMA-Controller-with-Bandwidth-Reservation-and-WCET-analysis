module axi_dma_ch #(
    parameter ADDR_W    = 32,
    parameter DATA_W    = 32,
    parameter BURST_LEN = 16,
    parameter LEN_W     = 16
)(
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 start,
    input  wire                 start_loop,
    input  wire                 stop_loop,
    input  wire [ADDR_W-1:0]    src,
    input  wire [ADDR_W-1:0]    dst,
    input  wire [LEN_W-1:0]     nbursts,
    input  wire                 clr_status,
    input  wire                 clr_perf,
    output reg                  busy,
    output reg                  done_pulse,
    output reg                  done_sticky,
    output reg                  err_sticky,
    output wire                 req,
    input  wire                 gnt,
    output wire                 rel,
    output reg  [31:0]          desc_lat_last,
    output reg  [31:0]          desc_lat_max,
    output reg  [31:0]          burst_lat_max,
    output reg  [31:0]          bursts_done,
    output reg  [ADDR_W-1:0]    araddr,
    output reg                  arvalid,
    input  wire                 arready,
    input  wire [DATA_W-1:0]    rdata,
    input  wire [1:0]           rresp,
    input  wire                 rlast,
    input  wire                 rvalid,
    output reg                  rready,
    output reg  [ADDR_W-1:0]    awaddr,
    output reg                  awvalid,
    input  wire                 awready,
    output wire [DATA_W-1:0]    wdata,
    output wire                 wvalid,
    output wire                 wlast,
    input  wire                 wready,
    input  wire [1:0]           bresp,
    input  wire                 bvalid,
    output reg                  bready
);
    localparam BURST_BYTES = BURST_LEN * DATA_W / 8;
    localparam IDX_W       = $clog2(BURST_LEN);

    localparam S_IDLE = 3'd0;
    localparam S_REQ  = 3'd1;
    localparam S_AR   = 3'd2;
    localparam S_R    = 3'd3;
    localparam S_WR   = 3'd4;
    localparam S_B    = 3'd5;

    reg [2:0]        state;
    reg [ADDR_W-1:0] src_r, dst_r, src0, dst0;
    reg [LEN_W-1:0]  left, nb0;
    reg              loop_r;
    reg              aw_done, w_done;
    reg [IDX_W-1:0]  ridx, widx;
    reg [DATA_W-1:0] buffer [0:BURST_LEN-1];
    reg [31:0]       dcnt, bcnt;

    assign req    = (state != S_IDLE);
    assign rel    = (state == S_B) && bvalid && bready;
    assign wvalid = (state == S_WR) && !w_done;
    assign wdata  = buffer[widx];
    assign wlast  = (widx == BURST_LEN-1);

    wire rd_fire = rvalid && rready;
    wire wr_fire = wvalid && wready;

    always @(posedge clk) begin
        if (!rst_n) begin
            state <= S_IDLE; busy <= 1'b0; done_pulse <= 1'b0; done_sticky <= 1'b0;
            err_sticky <= 1'b0; arvalid <= 1'b0; rready <= 1'b0; awvalid <= 1'b0;
            bready <= 1'b0; aw_done <= 1'b0; w_done <= 1'b0; loop_r <= 1'b0;
            ridx <= 0; widx <= 0; dcnt <= 0; bcnt <= 0; left <= 0;
            src_r <= 0; dst_r <= 0; src0 <= 0; dst0 <= 0; nb0 <= 0;
            araddr <= 0; awaddr <= 0;
            desc_lat_last <= 0; desc_lat_max <= 0; burst_lat_max <= 0; bursts_done <= 0;
        end else begin
            done_pulse <= 1'b0;
            if (clr_status) begin done_sticky <= 1'b0; err_sticky <= 1'b0; end
            if (clr_perf) begin desc_lat_last <= 0; desc_lat_max <= 0; burst_lat_max <= 0; bursts_done <= 0; end
            if (stop_loop) loop_r <= 1'b0;
            if (state != S_IDLE) begin dcnt <= dcnt + 1; bcnt <= bcnt + 1; end

            case (state)
                S_IDLE: begin
                    if (start && nbursts != 0) begin
                        src_r <= src; dst_r <= dst; left <= nbursts;
                        src0 <= src; dst0 <= dst; nb0 <= nbursts;
                        loop_r <= start_loop;
                        busy <= 1'b1; dcnt <= 1; bcnt <= 1;
                        state <= S_REQ;
                    end
                end
                S_REQ: begin
                    if (gnt) begin
                        araddr <= src_r; arvalid <= 1'b1; state <= S_AR;
                    end
                end
                S_AR: begin
                    if (arvalid && arready) begin
                        arvalid <= 1'b0; rready <= 1'b1; ridx <= 0; state <= S_R;
                    end
                end
                S_R: begin
                    if (rd_fire) begin
                        buffer[ridx] <= rdata;
                        ridx <= ridx + 1'b1;
                        if (rresp[1]) err_sticky <= 1'b1;
                        if (rlast) begin
                            rready <= 1'b0; awaddr <= dst_r; awvalid <= 1'b1;
                            aw_done <= 1'b0; w_done <= 1'b0; widx <= 0;
                            state <= S_WR;
                        end
                    end
                end
                S_WR: begin
                    if (awvalid && awready) begin awvalid <= 1'b0; aw_done <= 1'b1; end
                    if (wr_fire) begin
                        if (wlast) w_done <= 1'b1; else widx <= widx + 1'b1;
                    end
                    if (aw_done && w_done) begin bready <= 1'b1; state <= S_B; end
                end
                S_B: begin
                    if (bvalid && bready) begin
                        bready <= 1'b0;
                        if (bresp[1]) err_sticky <= 1'b1;
                        bursts_done <= bursts_done + 1'b1;
                        if (bcnt > burst_lat_max) burst_lat_max <= bcnt;
                        bcnt <= 1;
                        if (left == 1) begin
                            done_pulse <= 1'b1; done_sticky <= 1'b1;
                            desc_lat_last <= dcnt;
                            if (dcnt > desc_lat_max) desc_lat_max <= dcnt;
                            dcnt <= 1;
                            if (loop_r) begin
                                src_r <= src0; dst_r <= dst0; left <= nb0; state <= S_REQ;
                            end else begin
                                busy <= 1'b0; state <= S_IDLE;
                            end
                        end else begin
                            src_r <= src_r + BURST_BYTES; dst_r <= dst_r + BURST_BYTES;
                            left <= left - 1'b1; state <= S_REQ;
                        end
                    end
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule

module dma_sched #(
    parameter N_CH     = 4,
    parameter S_SLOTS  = 8,
    parameter SLOT_LEN = 64,
    parameter MODE     = 0,
    parameter OWN_W    = 2
)(
    input  wire                      clk,
    input  wire                      rst_n,
    input  wire [N_CH-1:0]           req,
    input  wire [N_CH-1:0]           rel,
    input  wire [S_SLOTS*OWN_W-1:0]  slot_tbl,
    input  wire                      clr_status,
    output reg  [N_CH-1:0]           gnt,
    output reg                       overrun,
    output wire [$clog2(S_SLOTS)-1:0] slot_idx_o
);
    localparam SIDX_W = $clog2(S_SLOTS);
    localparam CNT_W  = $clog2(SLOT_LEN);

    wire [N_CH-1:0] gnt_live = gnt & ~rel;
    wire            held     = |gnt_live;

    generate
    if (MODE == 0) begin : g_tdma
        reg [CNT_W-1:0]  cnt;
        reg [SIDX_W-1:0] sidx;
        wire             at_end = (cnt == SLOT_LEN-1);
        wire [SIDX_W-1:0] nidx  = (sidx == S_SLOTS-1) ? {SIDX_W{1'b0}} : sidx + 1'b1;
        wire [OWN_W-1:0]  nown  = slot_tbl[nidx*OWN_W +: OWN_W];
        assign slot_idx_o = sidx;

        always @(posedge clk) begin
            if (!rst_n) begin
                cnt <= 0; sidx <= 0; gnt <= 0; overrun <= 1'b0;
            end else begin
                gnt <= gnt_live;
                if (clr_status) overrun <= 1'b0;
                if (at_end) begin
                    if (held) begin
                        overrun <= 1'b1;
                    end else begin
                        cnt  <= 0;
                        sidx <= nidx;
                        if (req[nown] && !rel[nown]) gnt <= ({{(N_CH-1){1'b0}}, 1'b1} << nown);
                    end
                end else begin
                    cnt <= cnt + 1'b1;
                end
            end
        end
    end else begin : g_work_conserving
        reg  [OWN_W-1:0] last;
        reg  [N_CH-1:0]  pick;
        reg              found;
        integer          k, idx;
        assign slot_idx_o = {SIDX_W{1'b0}};

        always @* begin
            pick  = {N_CH{1'b0}};
            found = 1'b0;
            if (MODE == 1) begin
                for (k = 1; k <= N_CH; k = k + 1) begin
                    idx = (last + k) % N_CH;
                    if (!found && req[idx]) begin pick[idx] = 1'b1; found = 1'b1; end
                end
            end else begin
                for (k = 0; k < N_CH; k = k + 1) begin
                    if (!found && req[k]) begin pick[k] = 1'b1; found = 1'b1; end
                end
            end
        end

        always @(posedge clk) begin
            if (!rst_n) begin
                gnt <= 0; last <= 0; overrun <= 1'b0;
            end else begin
                if (clr_status) overrun <= 1'b0;
                gnt <= gnt_live;
                if (gnt == 0 && found) begin
                    gnt <= pick;
                    for (k = 0; k < N_CH; k = k + 1) if (pick[k]) last <= k;
                end
            end
        end
    end
    endgenerate
endmodule

module axi_dma_regs #(
    parameter N_CH        = 4,
    parameter S_SLOTS     = 8,
    parameter SLOT_LEN    = 64,
    parameter BURST_LEN   = 16,
    parameter DATA_W      = 32,
    parameter ADDR_W      = 32,
    parameter LEN_W       = 16,
    parameter OWN_W       = 2,
    parameter [S_SLOTS*OWN_W-1:0] DEFAULT_TBL = {2'd3,2'd0,2'd1,2'd0,2'd2,2'd0,2'd1,2'd0}
)(
    input  wire                     clk,
    input  wire                     rst_n,
    input  wire [11:0]              s_awaddr,
    input  wire                     s_awvalid,
    output wire                     s_awready,
    input  wire [31:0]              s_wdata,
    input  wire [3:0]               s_wstrb,
    input  wire                     s_wvalid,
    output wire                     s_wready,
    output wire [1:0]               s_bresp,
    output reg                      s_bvalid,
    input  wire                     s_bready,
    input  wire [11:0]              s_araddr,
    input  wire                     s_arvalid,
    output wire                     s_arready,
    output reg  [31:0]              s_rdata,
    output wire [1:0]               s_rresp,
    output reg                      s_rvalid,
    input  wire                     s_rready,

    output reg  [N_CH-1:0]          ch_start,
    output reg  [N_CH-1:0]          ch_start_loop,
    output reg  [N_CH-1:0]          ch_stop_loop,
    output reg  [N_CH*ADDR_W-1:0]   ch_src,
    output reg  [N_CH*ADDR_W-1:0]   ch_dst,
    output reg  [N_CH*LEN_W-1:0]    ch_nb,
    output reg                      clr_status,
    output reg                      clr_perf,
    output reg  [S_SLOTS*OWN_W-1:0] slot_tbl,

    input  wire [N_CH-1:0]          ch_busy,
    input  wire [N_CH-1:0]          ch_done_s,
    input  wire [N_CH-1:0]          ch_err,
    input  wire                     overrun,
    input  wire [N_CH*32-1:0]       ch_lat_last,
    input  wire [N_CH*32-1:0]       ch_lat_max,
    input  wire [N_CH*32-1:0]       ch_blat_max,
    input  wire [N_CH*32-1:0]       ch_bdone
);
    localparam BURST_BYTES = BURST_LEN * DATA_W / 8;
    localparam [7:0] N_CH_8 = N_CH;
    localparam [7:0] S_SLOTS_8 = S_SLOTS;
    localparam [7:0] BURST_LEN_8 = BURST_LEN;

    wire wr_go = s_awvalid && s_wvalid && !s_bvalid;
    assign s_awready = wr_go;
    assign s_wready  = wr_go;
    assign s_bresp   = 2'b00;
    assign s_rresp   = 2'b00;
    assign s_arready = s_arvalid && !s_rvalid;

    integer c, s;

    always @(posedge clk) begin
        if (!rst_n) begin
            s_bvalid <= 1'b0; ch_start <= 0; ch_start_loop <= 0; ch_stop_loop <= 0;
            ch_src <= 0; ch_dst <= 0; ch_nb <= 0; clr_status <= 1'b0; clr_perf <= 1'b0;
            slot_tbl <= DEFAULT_TBL;
        end else begin
            ch_start <= 0; ch_stop_loop <= 0; clr_status <= 1'b0; clr_perf <= 1'b0;
            if (s_bvalid && s_bready) s_bvalid <= 1'b0;
            if (wr_go) begin
                s_bvalid <= 1'b1;
                if (s_awaddr == 12'h000) begin
                    clr_status <= s_wdata[0];
                    clr_perf   <= s_wdata[1];
                end
                for (c = 0; c < N_CH; c = c + 1) begin
                    if (s_awaddr[11:6] == (6'd4 + c)) begin
                        case (s_awaddr[5:2])
                            4'd0: ch_src[c*ADDR_W +: ADDR_W] <= s_wdata & ~(BURST_BYTES-1);
                            4'd1: ch_dst[c*ADDR_W +: ADDR_W] <= s_wdata & ~(BURST_BYTES-1);
                            4'd2: ch_nb[c*LEN_W +: LEN_W]    <= s_wdata[LEN_W-1:0];
                            4'd3: begin
                                if (s_wdata[0]) begin ch_start[c] <= 1'b1; ch_start_loop[c] <= s_wdata[1]; end
                                if (s_wdata[2]) ch_stop_loop[c] <= 1'b1;
                            end
                            default: ;
                        endcase
                    end
                end
                if (s_awaddr[11:10] == 2'b01) begin
                    for (s = 0; s < S_SLOTS; s = s + 1)
                        if (s_awaddr[9:2] == s) slot_tbl[s*OWN_W +: OWN_W] <= s_wdata[OWN_W-1:0];
                end
            end
        end
    end

    reg [31:0] rd_val;
    always @* begin
        rd_val = 32'd0;
        if (s_araddr == 12'h004) begin
            rd_val[N_CH-1:0]       = ch_done_s;
            rd_val[8 +: N_CH]      = ch_busy;
            rd_val[16 +: N_CH]     = ch_err;
            rd_val[31]             = overrun;
        end else if (s_araddr == 12'h008) begin
            rd_val = {8'd0, BURST_LEN_8, S_SLOTS_8, N_CH_8};
        end else if (s_araddr == 12'h00C) begin
            rd_val = SLOT_LEN;
        end
        for (c = 0; c < N_CH; c = c + 1) begin
            if (s_araddr[11:6] == (6'd4 + c)) begin
                case (s_araddr[5:2])
                    4'd0: rd_val = ch_src[c*ADDR_W +: ADDR_W];
                    4'd1: rd_val = ch_dst[c*ADDR_W +: ADDR_W];
                    4'd2: rd_val = ch_nb[c*LEN_W +: LEN_W];
                    4'd4: rd_val = ch_lat_last[c*32 +: 32];
                    4'd5: rd_val = ch_lat_max[c*32 +: 32];
                    4'd6: rd_val = ch_blat_max[c*32 +: 32];
                    4'd7: rd_val = ch_bdone[c*32 +: 32];
                    default: ;
                endcase
            end
        end
        if (s_araddr[11:10] == 2'b01) begin
            for (s = 0; s < S_SLOTS; s = s + 1)
                if (s_araddr[9:2] == s) rd_val = slot_tbl[s*OWN_W +: OWN_W];
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            s_rvalid <= 1'b0; s_rdata <= 32'd0;
        end else begin
            if (s_arready) begin s_rvalid <= 1'b1; s_rdata <= rd_val; end
            else if (s_rvalid && s_rready) s_rvalid <= 1'b0;
        end
    end
endmodule

module axi_dma_top #(
    parameter N_CH        = 4,
    parameter S_SLOTS     = 8,
    parameter SLOT_LEN    = 64,
    parameter MODE        = 0,
    parameter DATA_W      = 32,
    parameter ADDR_W      = 32,
    parameter BURST_LEN   = 16,
    parameter LEN_W       = 16,
    parameter OWN_W       = 2,
    parameter [S_SLOTS*OWN_W-1:0] DEFAULT_TBL = {2'd3,2'd0,2'd1,2'd0,2'd2,2'd0,2'd1,2'd0}
)(
    input  wire                 clk,
    input  wire                 rst_n,

    input  wire [11:0]          s_axil_awaddr,
    input  wire                 s_axil_awvalid,
    output wire                 s_axil_awready,
    input  wire [31:0]          s_axil_wdata,
    input  wire [3:0]           s_axil_wstrb,
    input  wire                 s_axil_wvalid,
    output wire                 s_axil_wready,
    output wire [1:0]           s_axil_bresp,
    output wire                 s_axil_bvalid,
    input  wire                 s_axil_bready,
    input  wire [11:0]          s_axil_araddr,
    input  wire                 s_axil_arvalid,
    output wire                 s_axil_arready,
    output wire [31:0]          s_axil_rdata,
    output wire [1:0]           s_axil_rresp,
    output wire                 s_axil_rvalid,
    input  wire                 s_axil_rready,

    output reg  [OWN_W-1:0]     m_axi_arid,
    output reg  [ADDR_W-1:0]    m_axi_araddr,
    output wire [7:0]           m_axi_arlen,
    output wire [2:0]           m_axi_arsize,
    output wire [1:0]           m_axi_arburst,
    output wire                 m_axi_arlock,
    output wire [3:0]           m_axi_arcache,
    output wire [2:0]           m_axi_arprot,
    output wire [3:0]           m_axi_arqos,
    output reg                  m_axi_arvalid,
    input  wire                 m_axi_arready,
    input  wire [DATA_W-1:0]    m_axi_rdata,
    input  wire [1:0]           m_axi_rresp,
    input  wire                 m_axi_rlast,
    input  wire                 m_axi_rvalid,
    output reg                  m_axi_rready,

    output reg  [OWN_W-1:0]     m_axi_awid,
    output reg  [ADDR_W-1:0]    m_axi_awaddr,
    output wire [7:0]           m_axi_awlen,
    output wire [2:0]           m_axi_awsize,
    output wire [1:0]           m_axi_awburst,
    output wire                 m_axi_awlock,
    output wire [3:0]           m_axi_awcache,
    output wire [2:0]           m_axi_awprot,
    output wire [3:0]           m_axi_awqos,
    output reg                  m_axi_awvalid,
    input  wire                 m_axi_awready,
    output reg  [DATA_W-1:0]    m_axi_wdata,
    output wire [DATA_W/8-1:0]  m_axi_wstrb,
    output reg                  m_axi_wlast,
    output reg                  m_axi_wvalid,
    input  wire                 m_axi_wready,
    input  wire [1:0]           m_axi_bresp,
    input  wire                 m_axi_bvalid,
    output reg                  m_axi_bready,

    output wire                 irq,
    output wire [N_CH-1:0]      dbg_start,
    output wire [N_CH-1:0]      dbg_done,
    output wire [N_CH-1:0]      dbg_gnt,
    output wire [N_CH-1:0]      dbg_req,
    output wire                 dbg_overrun,
    output wire [$clog2(S_SLOTS)-1:0] dbg_slot
);
    localparam SIZE_CODE = $clog2(DATA_W/8);

    assign m_axi_arlen   = BURST_LEN - 1;
    assign m_axi_awlen   = BURST_LEN - 1;
    assign m_axi_arsize  = SIZE_CODE;
    assign m_axi_awsize  = SIZE_CODE;
    assign m_axi_arburst = 2'b01;
    assign m_axi_awburst = 2'b01;
    assign m_axi_arlock  = 1'b0;
    assign m_axi_awlock  = 1'b0;
    assign m_axi_arcache = 4'b0011;
    assign m_axi_awcache = 4'b0011;
    assign m_axi_arprot  = 3'b000;
    assign m_axi_awprot  = 3'b000;
    assign m_axi_arqos   = 4'b0000;
    assign m_axi_awqos   = 4'b0000;
    assign m_axi_wstrb   = {(DATA_W/8){1'b1}};

    wire [N_CH-1:0]          ch_start, ch_start_loop, ch_stop_loop;
    wire [N_CH*ADDR_W-1:0]   ch_src, ch_dst;
    wire [N_CH*LEN_W-1:0]    ch_nb;
    wire                     clr_status, clr_perf;
    wire [S_SLOTS*OWN_W-1:0] slot_tbl;

    wire [N_CH-1:0]          ch_busy, ch_done, ch_done_s, ch_err, ch_req, ch_rel, gnt;
    wire [N_CH*32-1:0]       ch_lat_last, ch_lat_max, ch_blat_max, ch_bdone;
    wire                     overrun;

    wire [N_CH*ADDR_W-1:0]   ch_araddr, ch_awaddr;
    wire [N_CH-1:0]          ch_arvalid, ch_rready, ch_awvalid, ch_wvalid, ch_wlast, ch_bready;
    wire [N_CH*DATA_W-1:0]   ch_wdata;

    assign irq         = |ch_done;
    assign dbg_start   = ch_start;
    assign dbg_done    = ch_done;
    assign dbg_gnt     = gnt;
    assign dbg_req     = ch_req;
    assign dbg_overrun = overrun;

    axi_dma_regs #(
        .N_CH(N_CH), .S_SLOTS(S_SLOTS), .SLOT_LEN(SLOT_LEN), .BURST_LEN(BURST_LEN),
        .DATA_W(DATA_W), .ADDR_W(ADDR_W), .LEN_W(LEN_W), .OWN_W(OWN_W), .DEFAULT_TBL(DEFAULT_TBL)
    ) u_regs (
        .clk(clk), .rst_n(rst_n),
        .s_awaddr(s_axil_awaddr), .s_awvalid(s_axil_awvalid), .s_awready(s_axil_awready),
        .s_wdata(s_axil_wdata), .s_wstrb(s_axil_wstrb), .s_wvalid(s_axil_wvalid), .s_wready(s_axil_wready),
        .s_bresp(s_axil_bresp), .s_bvalid(s_axil_bvalid), .s_bready(s_axil_bready),
        .s_araddr(s_axil_araddr), .s_arvalid(s_axil_arvalid), .s_arready(s_axil_arready),
        .s_rdata(s_axil_rdata), .s_rresp(s_axil_rresp), .s_rvalid(s_axil_rvalid), .s_rready(s_axil_rready),
        .ch_start(ch_start), .ch_start_loop(ch_start_loop), .ch_stop_loop(ch_stop_loop),
        .ch_src(ch_src), .ch_dst(ch_dst), .ch_nb(ch_nb),
        .clr_status(clr_status), .clr_perf(clr_perf), .slot_tbl(slot_tbl),
        .ch_busy(ch_busy), .ch_done_s(ch_done_s), .ch_err(ch_err), .overrun(overrun),
        .ch_lat_last(ch_lat_last), .ch_lat_max(ch_lat_max), .ch_blat_max(ch_blat_max), .ch_bdone(ch_bdone)
    );

    dma_sched #(
        .N_CH(N_CH), .S_SLOTS(S_SLOTS), .SLOT_LEN(SLOT_LEN), .MODE(MODE), .OWN_W(OWN_W)
    ) u_sched (
        .clk(clk), .rst_n(rst_n), .req(ch_req), .rel(ch_rel), .slot_tbl(slot_tbl),
        .clr_status(clr_status), .gnt(gnt), .overrun(overrun), .slot_idx_o(dbg_slot)
    );

    wire [N_CH-1:0] ch_arready = gnt & {N_CH{m_axi_arready}};
    wire [N_CH-1:0] ch_rvalid  = gnt & {N_CH{m_axi_rvalid}};
    wire [N_CH-1:0] ch_awready = gnt & {N_CH{m_axi_awready}};
    wire [N_CH-1:0] ch_wready  = gnt & {N_CH{m_axi_wready}};
    wire [N_CH-1:0] ch_bvalid  = gnt & {N_CH{m_axi_bvalid}};

    genvar g;
    generate
        for (g = 0; g < N_CH; g = g + 1) begin : g_ch
            axi_dma_ch #(
                .ADDR_W(ADDR_W), .DATA_W(DATA_W), .BURST_LEN(BURST_LEN), .LEN_W(LEN_W)
            ) u_ch (
                .clk(clk), .rst_n(rst_n),
                .start(ch_start[g]), .start_loop(ch_start_loop[g]), .stop_loop(ch_stop_loop[g]),
                .src(ch_src[g*ADDR_W +: ADDR_W]), .dst(ch_dst[g*ADDR_W +: ADDR_W]),
                .nbursts(ch_nb[g*LEN_W +: LEN_W]),
                .clr_status(clr_status), .clr_perf(clr_perf),
                .busy(ch_busy[g]), .done_pulse(ch_done[g]), .done_sticky(ch_done_s[g]),
                .err_sticky(ch_err[g]), .req(ch_req[g]), .gnt(gnt[g]), .rel(ch_rel[g]),
                .desc_lat_last(ch_lat_last[g*32 +: 32]), .desc_lat_max(ch_lat_max[g*32 +: 32]),
                .burst_lat_max(ch_blat_max[g*32 +: 32]), .bursts_done(ch_bdone[g*32 +: 32]),
                .araddr(ch_araddr[g*ADDR_W +: ADDR_W]), .arvalid(ch_arvalid[g]), .arready(ch_arready[g]),
                .rdata(m_axi_rdata), .rresp(m_axi_rresp), .rlast(m_axi_rlast),
                .rvalid(ch_rvalid[g]), .rready(ch_rready[g]),
                .awaddr(ch_awaddr[g*ADDR_W +: ADDR_W]), .awvalid(ch_awvalid[g]), .awready(ch_awready[g]),
                .wdata(ch_wdata[g*DATA_W +: DATA_W]), .wvalid(ch_wvalid[g]), .wlast(ch_wlast[g]),
                .wready(ch_wready[g]),
                .bresp(m_axi_bresp), .bvalid(ch_bvalid[g]), .bready(ch_bready[g])
            );
        end
    endgenerate

    integer i;
    always @* begin
        m_axi_arid = 0; m_axi_araddr = 0; m_axi_arvalid = 1'b0; m_axi_rready = 1'b0;
        m_axi_awid = 0; m_axi_awaddr = 0; m_axi_awvalid = 1'b0;
        m_axi_wdata = 0; m_axi_wlast = 1'b0; m_axi_wvalid = 1'b0; m_axi_bready = 1'b0;
        for (i = 0; i < N_CH; i = i + 1) begin
            if (gnt[i]) begin
                m_axi_arid    = i;
                m_axi_awid    = i;
                m_axi_araddr  = ch_araddr[i*ADDR_W +: ADDR_W];
                m_axi_arvalid = ch_arvalid[i];
                m_axi_rready  = ch_rready[i];
                m_axi_awaddr  = ch_awaddr[i*ADDR_W +: ADDR_W];
                m_axi_awvalid = ch_awvalid[i];
                m_axi_wdata   = ch_wdata[i*DATA_W +: DATA_W];
                m_axi_wlast   = ch_wlast[i];
                m_axi_wvalid  = ch_wvalid[i];
                m_axi_bready  = ch_bready[i];
            end
        end
    end
endmodule

module axi_mem_model #(
    parameter ADDR_W    = 32,
    parameter DATA_W    = 32,
    parameter MEM_WORDS = 32768,
    parameter RD_LAT    = 8,
    parameter WR_LAT    = 4,
    parameter JITTER    = 0
)(
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire [ADDR_W-1:0]    araddr,
    input  wire [7:0]           arlen,
    input  wire                 arvalid,
    output wire                 arready,
    output wire [DATA_W-1:0]    rdata,
    output wire [1:0]           rresp,
    output wire                 rlast,
    output wire                 rvalid,
    input  wire                 rready,
    input  wire [ADDR_W-1:0]    awaddr,
    input  wire [7:0]           awlen,
    input  wire                 awvalid,
    output wire                 awready,
    input  wire [DATA_W-1:0]    wdata,
    input  wire                 wlast,
    input  wire                 wvalid,
    output wire                 wready,
    output wire [1:0]           bresp,
    output wire                 bvalid,
    input  wire                 bready
);
    localparam IDX_W = $clog2(MEM_WORDS);
    localparam BYTE_SH = $clog2(DATA_W/8);

    reg [DATA_W-1:0] mem [0:MEM_WORDS-1];

    reg [15:0] lfsr;
    wire [15:0] lfsr_n = {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
    wire [7:0]  jit    = (JITTER == 0) ? 8'd0 : (lfsr[7:0] % (JITTER + 1));

    localparam R_IDLE = 2'd0, R_WAIT = 2'd1, R_DATA = 2'd2;
    reg [1:0]        rst_s;
    reg [ADDR_W-1:0] raddr;
    reg [7:0]        rbeats, rcnt;

    assign arready = (rst_s == R_IDLE);
    assign rvalid  = (rst_s == R_DATA);
    assign rdata   = mem[raddr[IDX_W+BYTE_SH-1:BYTE_SH]];
    assign rresp   = 2'b00;
    assign rlast   = (rbeats == 0);

    localparam W_IDLE = 2'd0, W_DATA = 2'd1, W_WAIT = 2'd2, W_RESP = 2'd3;
    reg [1:0]        wst_s;
    reg [ADDR_W-1:0] waddr;
    reg [7:0]        wcnt;

    assign awready = (wst_s == W_IDLE);
    assign wready  = (wst_s == W_DATA);
    assign bvalid  = (wst_s == W_RESP);
    assign bresp   = 2'b00;

    always @(posedge clk) begin
        if (!rst_n) begin
            lfsr <= 16'hACE1; rst_s <= R_IDLE; wst_s <= W_IDLE;
            raddr <= 0; rbeats <= 0; rcnt <= 0; waddr <= 0; wcnt <= 0;
        end else begin
            lfsr <= lfsr_n;

            case (rst_s)
                R_IDLE: if (arvalid) begin
                    raddr  <= araddr;
                    rbeats <= arlen;
                    rcnt   <= RD_LAT + jit - 1;
                    rst_s  <= R_WAIT;
                end
                R_WAIT: begin
                    if (rcnt == 0) rst_s <= R_DATA; else rcnt <= rcnt - 1'b1;
                end
                R_DATA: if (rready) begin
                    raddr <= raddr + (DATA_W/8);
                    if (rbeats == 0) rst_s <= R_IDLE; else rbeats <= rbeats - 1'b1;
                end
                default: rst_s <= R_IDLE;
            endcase

            case (wst_s)
                W_IDLE: if (awvalid) begin
                    waddr <= awaddr;
                    wst_s <= W_DATA;
                end
                W_DATA: if (wvalid) begin
                    mem[waddr[IDX_W+BYTE_SH-1:BYTE_SH]] <= wdata;
                    waddr <= waddr + (DATA_W/8);
                    if (wlast) begin
                        wcnt  <= WR_LAT + jit - 1;
                        wst_s <= W_WAIT;
                    end
                end
                W_WAIT: begin
                    if (wcnt == 0) wst_s <= W_RESP; else wcnt <= wcnt - 1'b1;
                end
                W_RESP: if (bready) wst_s <= W_IDLE;
                default: wst_s <= W_IDLE;
            endcase
        end
    end
endmodule

