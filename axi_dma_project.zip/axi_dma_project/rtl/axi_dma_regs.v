module axi_dma_regs #(
    parameter N_CH        = 4,
    parameter S_SLOTS     = 8,
    parameter SLOT_LEN    = 64,
    parameter BURST_LEN   = 16,
    parameter DATA_W      = 32,
    parameter ADDR_W      = 32,
    parameter LEN_W       = 16,
    parameter OWN_W       = 2,
    parameter [S_SLOTS*OWN_W-1:0] DEFAULT_TBL = {2'd3,2'd0,2'd1,2'd0,2'd2,2'd0,2'd1,2'd0}
)(
    input  wire                     clk,
    input  wire                     rst_n,
    input  wire [11:0]              s_awaddr,
    input  wire                     s_awvalid,
    output wire                     s_awready,
    input  wire [31:0]              s_wdata,
    input  wire [3:0]               s_wstrb,
    input  wire                     s_wvalid,
    output wire                     s_wready,
    output wire [1:0]               s_bresp,
    output reg                      s_bvalid,
    input  wire                     s_bready,
    input  wire [11:0]              s_araddr,
    input  wire                     s_arvalid,
    output wire                     s_arready,
    output reg  [31:0]              s_rdata,
    output wire [1:0]               s_rresp,
    output reg                      s_rvalid,
    input  wire                     s_rready,

    output reg  [N_CH-1:0]          ch_start,
    output reg  [N_CH-1:0]          ch_start_loop,
    output reg  [N_CH-1:0]          ch_stop_loop,
    output reg  [N_CH*ADDR_W-1:0]   ch_src,
    output reg  [N_CH*ADDR_W-1:0]   ch_dst,
    output reg  [N_CH*LEN_W-1:0]    ch_nb,
    output reg                      clr_status,
    output reg                      clr_perf,
    output reg  [S_SLOTS*OWN_W-1:0] slot_tbl,

    input  wire [N_CH-1:0]          ch_busy,
    input  wire [N_CH-1:0]          ch_done_s,
    input  wire [N_CH-1:0]          ch_err,
    input  wire                     overrun,
    input  wire [N_CH*32-1:0]       ch_lat_last,
    input  wire [N_CH*32-1:0]       ch_lat_max,
    input  wire [N_CH*32-1:0]       ch_blat_max,
    input  wire [N_CH*32-1:0]       ch_bdone
);
    localparam BURST_BYTES = BURST_LEN * DATA_W / 8;
    localparam [7:0] N_CH_8 = N_CH;
    localparam [7:0] S_SLOTS_8 = S_SLOTS;
    localparam [7:0] BURST_LEN_8 = BURST_LEN;

    wire wr_go = s_awvalid && s_wvalid && !s_bvalid;
    assign s_awready = wr_go;
    assign s_wready  = wr_go;
    assign s_bresp   = 2'b00;
    assign s_rresp   = 2'b00;
    assign s_arready = s_arvalid && !s_rvalid;

    integer c, s;

    always @(posedge clk) begin
        if (!rst_n) begin
            s_bvalid <= 1'b0; ch_start <= 0; ch_start_loop <= 0; ch_stop_loop <= 0;
            ch_src <= 0; ch_dst <= 0; ch_nb <= 0; clr_status <= 1'b0; clr_perf <= 1'b0;
            slot_tbl <= DEFAULT_TBL;
        end else begin
            ch_start <= 0; ch_stop_loop <= 0; clr_status <= 1'b0; clr_perf <= 1'b0;
            if (s_bvalid && s_bready) s_bvalid <= 1'b0;
            if (wr_go) begin
                s_bvalid <= 1'b1;
                if (s_awaddr == 12'h000) begin
                    clr_status <= s_wdata[0];
                    clr_perf   <= s_wdata[1];
                end
                for (c = 0; c < N_CH; c = c + 1) begin
                    if (s_awaddr[11:6] == (6'd4 + c)) begin
                        case (s_awaddr[5:2])
                            4'd0: ch_src[c*ADDR_W +: ADDR_W] <= s_wdata & ~(BURST_BYTES-1);
                            4'd1: ch_dst[c*ADDR_W +: ADDR_W] <= s_wdata & ~(BURST_BYTES-1);
                            4'd2: ch_nb[c*LEN_W +: LEN_W]    <= s_wdata[LEN_W-1:0];
                            4'd3: begin
                                if (s_wdata[0]) begin ch_start[c] <= 1'b1; ch_start_loop[c] <= s_wdata[1]; end
                                if (s_wdata[2]) ch_stop_loop[c] <= 1'b1;
                            end
                            default: ;
                        endcase
                    end
                end
                if (s_awaddr[11:10] == 2'b01) begin
                    for (s = 0; s < S_SLOTS; s = s + 1)
                        if (s_awaddr[9:2] == s) slot_tbl[s*OWN_W +: OWN_W] <= s_wdata[OWN_W-1:0];
                end
            end
        end
    end

    reg [31:0] rd_val;
    always @* begin
        rd_val = 32'd0;
        if (s_araddr == 12'h004) begin
            rd_val[N_CH-1:0]       = ch_done_s;
            rd_val[8 +: N_CH]      = ch_busy;
            rd_val[16 +: N_CH]     = ch_err;
            rd_val[31]             = overrun;
        end else if (s_araddr == 12'h008) begin
            rd_val = {8'd0, BURST_LEN_8, S_SLOTS_8, N_CH_8};
        end else if (s_araddr == 12'h00C) begin
            rd_val = SLOT_LEN;
        end
        for (c = 0; c < N_CH; c = c + 1) begin
            if (s_araddr[11:6] == (6'd4 + c)) begin
                case (s_araddr[5:2])
                    4'd0: rd_val = ch_src[c*ADDR_W +: ADDR_W];
                    4'd1: rd_val = ch_dst[c*ADDR_W +: ADDR_W];
                    4'd2: rd_val = ch_nb[c*LEN_W +: LEN_W];
                    4'd4: rd_val = ch_lat_last[c*32 +: 32];
                    4'd5: rd_val = ch_lat_max[c*32 +: 32];
                    4'd6: rd_val = ch_blat_max[c*32 +: 32];
                    4'd7: rd_val = ch_bdone[c*32 +: 32];
                    default: ;
                endcase
            end
        end
        if (s_araddr[11:10] == 2'b01) begin
            for (s = 0; s < S_SLOTS; s = s + 1)
                if (s_araddr[9:2] == s) rd_val = slot_tbl[s*OWN_W +: OWN_W];
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            s_rvalid <= 1'b0; s_rdata <= 32'd0;
        end else begin
            if (s_arready) begin s_rvalid <= 1'b1; s_rdata <= rd_val; end
            else if (s_rvalid && s_rready) s_rvalid <= 1'b0;
        end
    end
endmodule
