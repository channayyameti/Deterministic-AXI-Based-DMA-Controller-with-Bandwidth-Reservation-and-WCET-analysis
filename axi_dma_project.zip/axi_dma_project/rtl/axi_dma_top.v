module axi_dma_top #(
    parameter N_CH        = 4,
    parameter S_SLOTS     = 8,
    parameter SLOT_LEN    = 64,
    parameter MODE        = 0,
    parameter DATA_W      = 32,
    parameter ADDR_W      = 32,
    parameter BURST_LEN   = 16,
    parameter LEN_W       = 16,
    parameter OWN_W       = 2,
    parameter [S_SLOTS*OWN_W-1:0] DEFAULT_TBL = {2'd3,2'd0,2'd1,2'd0,2'd2,2'd0,2'd1,2'd0}
)(
    input  wire                 clk,
    input  wire                 rst_n,

    input  wire [11:0]          s_axil_awaddr,
    input  wire                 s_axil_awvalid,
    output wire                 s_axil_awready,
    input  wire [31:0]          s_axil_wdata,
    input  wire [3:0]           s_axil_wstrb,
    input  wire                 s_axil_wvalid,
    output wire                 s_axil_wready,
    output wire [1:0]           s_axil_bresp,
    output wire                 s_axil_bvalid,
    input  wire                 s_axil_bready,
    input  wire [11:0]          s_axil_araddr,
    input  wire                 s_axil_arvalid,
    output wire                 s_axil_arready,
    output wire [31:0]          s_axil_rdata,
    output wire [1:0]           s_axil_rresp,
    output wire                 s_axil_rvalid,
    input  wire                 s_axil_rready,

    output reg  [OWN_W-1:0]     m_axi_arid,
    output reg  [ADDR_W-1:0]    m_axi_araddr,
    output wire [7:0]           m_axi_arlen,
    output wire [2:0]           m_axi_arsize,
    output wire [1:0]           m_axi_arburst,
    output wire                 m_axi_arlock,
    output wire [3:0]           m_axi_arcache,
    output wire [2:0]           m_axi_arprot,
    output wire [3:0]           m_axi_arqos,
    output reg                  m_axi_arvalid,
    input  wire                 m_axi_arready,
    input  wire [DATA_W-1:0]    m_axi_rdata,
    input  wire [1:0]           m_axi_rresp,
    input  wire                 m_axi_rlast,
    input  wire                 m_axi_rvalid,
    output reg                  m_axi_rready,

    output reg  [OWN_W-1:0]     m_axi_awid,
    output reg  [ADDR_W-1:0]    m_axi_awaddr,
    output wire [7:0]           m_axi_awlen,
    output wire [2:0]           m_axi_awsize,
    output wire [1:0]           m_axi_awburst,
    output wire                 m_axi_awlock,
    output wire [3:0]           m_axi_awcache,
    output wire [2:0]           m_axi_awprot,
    output wire [3:0]           m_axi_awqos,
    output reg                  m_axi_awvalid,
    input  wire                 m_axi_awready,
    output reg  [DATA_W-1:0]    m_axi_wdata,
    output wire [DATA_W/8-1:0]  m_axi_wstrb,
    output reg                  m_axi_wlast,
    output reg                  m_axi_wvalid,
    input  wire                 m_axi_wready,
    input  wire [1:0]           m_axi_bresp,
    input  wire                 m_axi_bvalid,
    output reg                  m_axi_bready,

    output wire                 irq,
    output wire [N_CH-1:0]      dbg_start,
    output wire [N_CH-1:0]      dbg_done,
    output wire [N_CH-1:0]      dbg_gnt,
    output wire [N_CH-1:0]      dbg_req,
    output wire                 dbg_overrun,
    output wire [$clog2(S_SLOTS)-1:0] dbg_slot
);
    localparam SIZE_CODE = $clog2(DATA_W/8);

    assign m_axi_arlen   = BURST_LEN - 1;
    assign m_axi_awlen   = BURST_LEN - 1;
    assign m_axi_arsize  = SIZE_CODE;
    assign m_axi_awsize  = SIZE_CODE;
    assign m_axi_arburst = 2'b01;
    assign m_axi_awburst = 2'b01;
    assign m_axi_arlock  = 1'b0;
    assign m_axi_awlock  = 1'b0;
    assign m_axi_arcache = 4'b0011;
    assign m_axi_awcache = 4'b0011;
    assign m_axi_arprot  = 3'b000;
    assign m_axi_awprot  = 3'b000;
    assign m_axi_arqos   = 4'b0000;
    assign m_axi_awqos   = 4'b0000;
    assign m_axi_wstrb   = {(DATA_W/8){1'b1}};

    wire [N_CH-1:0]          ch_start, ch_start_loop, ch_stop_loop;
    wire [N_CH*ADDR_W-1:0]   ch_src, ch_dst;
    wire [N_CH*LEN_W-1:0]    ch_nb;
    wire                     clr_status, clr_perf;
    wire [S_SLOTS*OWN_W-1:0] slot_tbl;

    wire [N_CH-1:0]          ch_busy, ch_done, ch_done_s, ch_err, ch_req, ch_rel, gnt;
    wire [N_CH*32-1:0]       ch_lat_last, ch_lat_max, ch_blat_max, ch_bdone;
    wire                     overrun;

    wire [N_CH*ADDR_W-1:0]   ch_araddr, ch_awaddr;
    wire [N_CH-1:0]          ch_arvalid, ch_rready, ch_awvalid, ch_wvalid, ch_wlast, ch_bready;
    wire [N_CH*DATA_W-1:0]   ch_wdata;

    assign irq         = |ch_done;
    assign dbg_start   = ch_start;
    assign dbg_done    = ch_done;
    assign dbg_gnt     = gnt;
    assign dbg_req     = ch_req;
    assign dbg_overrun = overrun;

    axi_dma_regs #(
        .N_CH(N_CH), .S_SLOTS(S_SLOTS), .SLOT_LEN(SLOT_LEN), .BURST_LEN(BURST_LEN),
        .DATA_W(DATA_W), .ADDR_W(ADDR_W), .LEN_W(LEN_W), .OWN_W(OWN_W), .DEFAULT_TBL(DEFAULT_TBL)
    ) u_regs (
        .clk(clk), .rst_n(rst_n),
        .s_awaddr(s_axil_awaddr), .s_awvalid(s_axil_awvalid), .s_awready(s_axil_awready),
        .s_wdata(s_axil_wdata), .s_wstrb(s_axil_wstrb), .s_wvalid(s_axil_wvalid), .s_wready(s_axil_wready),
        .s_bresp(s_axil_bresp), .s_bvalid(s_axil_bvalid), .s_bready(s_axil_bready),
        .s_araddr(s_axil_araddr), .s_arvalid(s_axil_arvalid), .s_arready(s_axil_arready),
        .s_rdata(s_axil_rdata), .s_rresp(s_axil_rresp), .s_rvalid(s_axil_rvalid), .s_rready(s_axil_rready),
        .ch_start(ch_start), .ch_start_loop(ch_start_loop), .ch_stop_loop(ch_stop_loop),
        .ch_src(ch_src), .ch_dst(ch_dst), .ch_nb(ch_nb),
        .clr_status(clr_status), .clr_perf(clr_perf), .slot_tbl(slot_tbl),
        .ch_busy(ch_busy), .ch_done_s(ch_done_s), .ch_err(ch_err), .overrun(overrun),
        .ch_lat_last(ch_lat_last), .ch_lat_max(ch_lat_max), .ch_blat_max(ch_blat_max), .ch_bdone(ch_bdone)
    );

    dma_sched #(
        .N_CH(N_CH), .S_SLOTS(S_SLOTS), .SLOT_LEN(SLOT_LEN), .MODE(MODE), .OWN_W(OWN_W)
    ) u_sched (
        .clk(clk), .rst_n(rst_n), .req(ch_req), .rel(ch_rel), .slot_tbl(slot_tbl),
        .clr_status(clr_status), .gnt(gnt), .overrun(overrun), .slot_idx_o(dbg_slot)
    );

    wire [N_CH-1:0] ch_arready = gnt & {N_CH{m_axi_arready}};
    wire [N_CH-1:0] ch_rvalid  = gnt & {N_CH{m_axi_rvalid}};
    wire [N_CH-1:0] ch_awready = gnt & {N_CH{m_axi_awready}};
    wire [N_CH-1:0] ch_wready  = gnt & {N_CH{m_axi_wready}};
    wire [N_CH-1:0] ch_bvalid  = gnt & {N_CH{m_axi_bvalid}};

    genvar g;
    generate
        for (g = 0; g < N_CH; g = g + 1) begin : g_ch
            axi_dma_ch #(
                .ADDR_W(ADDR_W), .DATA_W(DATA_W), .BURST_LEN(BURST_LEN), .LEN_W(LEN_W)
            ) u_ch (
                .clk(clk), .rst_n(rst_n),
                .start(ch_start[g]), .start_loop(ch_start_loop[g]), .stop_loop(ch_stop_loop[g]),
                .src(ch_src[g*ADDR_W +: ADDR_W]), .dst(ch_dst[g*ADDR_W +: ADDR_W]),
                .nbursts(ch_nb[g*LEN_W +: LEN_W]),
                .clr_status(clr_status), .clr_perf(clr_perf),
                .busy(ch_busy[g]), .done_pulse(ch_done[g]), .done_sticky(ch_done_s[g]),
                .err_sticky(ch_err[g]), .req(ch_req[g]), .gnt(gnt[g]), .rel(ch_rel[g]),
                .desc_lat_last(ch_lat_last[g*32 +: 32]), .desc_lat_max(ch_lat_max[g*32 +: 32]),
                .burst_lat_max(ch_blat_max[g*32 +: 32]), .bursts_done(ch_bdone[g*32 +: 32]),
                .araddr(ch_araddr[g*ADDR_W +: ADDR_W]), .arvalid(ch_arvalid[g]), .arready(ch_arready[g]),
                .rdata(m_axi_rdata), .rresp(m_axi_rresp), .rlast(m_axi_rlast),
                .rvalid(ch_rvalid[g]), .rready(ch_rready[g]),
                .awaddr(ch_awaddr[g*ADDR_W +: ADDR_W]), .awvalid(ch_awvalid[g]), .awready(ch_awready[g]),
                .wdata(ch_wdata[g*DATA_W +: DATA_W]), .wvalid(ch_wvalid[g]), .wlast(ch_wlast[g]),
                .wready(ch_wready[g]),
                .bresp(m_axi_bresp), .bvalid(ch_bvalid[g]), .bready(ch_bready[g])
            );
        end
    endgenerate

    integer i;
    always @* begin
        m_axi_arid = 0; m_axi_araddr = 0; m_axi_arvalid = 1'b0; m_axi_rready = 1'b0;
        m_axi_awid = 0; m_axi_awaddr = 0; m_axi_awvalid = 1'b0;
        m_axi_wdata = 0; m_axi_wlast = 1'b0; m_axi_wvalid = 1'b0; m_axi_bready = 1'b0;
        for (i = 0; i < N_CH; i = i + 1) begin
            if (gnt[i]) begin
                m_axi_arid    = i;
                m_axi_awid    = i;
                m_axi_araddr  = ch_araddr[i*ADDR_W +: ADDR_W];
                m_axi_arvalid = ch_arvalid[i];
                m_axi_rready  = ch_rready[i];
                m_axi_awaddr  = ch_awaddr[i*ADDR_W +: ADDR_W];
                m_axi_awvalid = ch_awvalid[i];
                m_axi_wdata   = ch_wdata[i*DATA_W +: DATA_W];
                m_axi_wlast   = ch_wlast[i];
                m_axi_wvalid  = ch_wvalid[i];
                m_axi_bready  = ch_bready[i];
            end
        end
    end
endmodule
