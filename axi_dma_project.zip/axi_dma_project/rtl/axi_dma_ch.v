module axi_dma_ch #(
    parameter ADDR_W    = 32,
    parameter DATA_W    = 32,
    parameter BURST_LEN = 16,
    parameter LEN_W     = 16
)(
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 start,
    input  wire                 start_loop,
    input  wire                 stop_loop,
    input  wire [ADDR_W-1:0]    src,
    input  wire [ADDR_W-1:0]    dst,
    input  wire [LEN_W-1:0]     nbursts,
    input  wire                 clr_status,
    input  wire                 clr_perf,
    output reg                  busy,
    output reg                  done_pulse,
    output reg                  done_sticky,
    output reg                  err_sticky,
    output wire                 req,
    input  wire                 gnt,
    output wire                 rel,
    output reg  [31:0]          desc_lat_last,
    output reg  [31:0]          desc_lat_max,
    output reg  [31:0]          burst_lat_max,
    output reg  [31:0]          bursts_done,
    output reg  [ADDR_W-1:0]    araddr,
    output reg                  arvalid,
    input  wire                 arready,
    input  wire [DATA_W-1:0]    rdata,
    input  wire [1:0]           rresp,
    input  wire                 rlast,
    input  wire                 rvalid,
    output reg                  rready,
    output reg  [ADDR_W-1:0]    awaddr,
    output reg                  awvalid,
    input  wire                 awready,
    output wire [DATA_W-1:0]    wdata,
    output wire                 wvalid,
    output wire                 wlast,
    input  wire                 wready,
    input  wire [1:0]           bresp,
    input  wire                 bvalid,
    output reg                  bready
);
    localparam BURST_BYTES = BURST_LEN * DATA_W / 8;
    localparam IDX_W       = $clog2(BURST_LEN);

    localparam S_IDLE = 3'd0;
    localparam S_REQ  = 3'd1;
    localparam S_AR   = 3'd2;
    localparam S_R    = 3'd3;
    localparam S_WR   = 3'd4;
    localparam S_B    = 3'd5;

    reg [2:0]        state;
    reg [ADDR_W-1:0] src_r, dst_r, src0, dst0;
    reg [LEN_W-1:0]  left, nb0;
    reg              loop_r;
    reg              aw_done, w_done;
    reg [IDX_W-1:0]  ridx, widx;
    reg [DATA_W-1:0] buffer [0:BURST_LEN-1];
    reg [31:0]       dcnt, bcnt;

    assign req    = (state != S_IDLE);
    assign rel    = (state == S_B) && bvalid && bready;
    assign wvalid = (state == S_WR) && !w_done;
    assign wdata  = buffer[widx];
    assign wlast  = (widx == BURST_LEN-1);

    wire rd_fire = rvalid && rready;
    wire wr_fire = wvalid && wready;

    always @(posedge clk) begin
        if (!rst_n) begin
            state <= S_IDLE; busy <= 1'b0; done_pulse <= 1'b0; done_sticky <= 1'b0;
            err_sticky <= 1'b0; arvalid <= 1'b0; rready <= 1'b0; awvalid <= 1'b0;
            bready <= 1'b0; aw_done <= 1'b0; w_done <= 1'b0; loop_r <= 1'b0;
            ridx <= 0; widx <= 0; dcnt <= 0; bcnt <= 0; left <= 0;
            src_r <= 0; dst_r <= 0; src0 <= 0; dst0 <= 0; nb0 <= 0;
            araddr <= 0; awaddr <= 0;
            desc_lat_last <= 0; desc_lat_max <= 0; burst_lat_max <= 0; bursts_done <= 0;
        end else begin
            done_pulse <= 1'b0;
            if (clr_status) begin done_sticky <= 1'b0; err_sticky <= 1'b0; end
            if (clr_perf) begin desc_lat_last <= 0; desc_lat_max <= 0; burst_lat_max <= 0; bursts_done <= 0; end
            if (stop_loop) loop_r <= 1'b0;
            if (state != S_IDLE) begin dcnt <= dcnt + 1; bcnt <= bcnt + 1; end

            case (state)
                S_IDLE: begin
                    if (start && nbursts != 0) begin
                        src_r <= src; dst_r <= dst; left <= nbursts;
                        src0 <= src; dst0 <= dst; nb0 <= nbursts;
                        loop_r <= start_loop;
                        busy <= 1'b1; dcnt <= 1; bcnt <= 1;
                        state <= S_REQ;
                    end
                end
                S_REQ: begin
                    if (gnt) begin
                        araddr <= src_r; arvalid <= 1'b1; state <= S_AR;
                    end
                end
                S_AR: begin
                    if (arvalid && arready) begin
                        arvalid <= 1'b0; rready <= 1'b1; ridx <= 0; state <= S_R;
                    end
                end
                S_R: begin
                    if (rd_fire) begin
                        buffer[ridx] <= rdata;
                        ridx <= ridx + 1'b1;
                        if (rresp[1]) err_sticky <= 1'b1;
                        if (rlast) begin
                            rready <= 1'b0; awaddr <= dst_r; awvalid <= 1'b1;
                            aw_done <= 1'b0; w_done <= 1'b0; widx <= 0;
                            state <= S_WR;
                        end
                    end
                end
                S_WR: begin
                    if (awvalid && awready) begin awvalid <= 1'b0; aw_done <= 1'b1; end
                    if (wr_fire) begin
                        if (wlast) w_done <= 1'b1; else widx <= widx + 1'b1;
                    end
                    if (aw_done && w_done) begin bready <= 1'b1; state <= S_B; end
                end
                S_B: begin
                    if (bvalid && bready) begin
                        bready <= 1'b0;
                        if (bresp[1]) err_sticky <= 1'b1;
                        bursts_done <= bursts_done + 1'b1;
                        if (bcnt > burst_lat_max) burst_lat_max <= bcnt;
                        bcnt <= 1;
                        if (left == 1) begin
                            done_pulse <= 1'b1; done_sticky <= 1'b1;
                            desc_lat_last <= dcnt;
                            if (dcnt > desc_lat_max) desc_lat_max <= dcnt;
                            dcnt <= 1;
                            if (loop_r) begin
                                src_r <= src0; dst_r <= dst0; left <= nb0; state <= S_REQ;
                            end else begin
                                busy <= 1'b0; state <= S_IDLE;
                            end
                        end else begin
                            src_r <= src_r + BURST_BYTES; dst_r <= dst_r + BURST_BYTES;
                            left <= left - 1'b1; state <= S_REQ;
                        end
                    end
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
