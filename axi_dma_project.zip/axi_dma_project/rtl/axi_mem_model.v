module axi_mem_model #(
    parameter ADDR_W    = 32,
    parameter DATA_W    = 32,
    parameter MEM_WORDS = 32768,
    parameter RD_LAT    = 8,
    parameter WR_LAT    = 4,
    parameter JITTER    = 0
)(
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire [ADDR_W-1:0]    araddr,
    input  wire [7:0]           arlen,
    input  wire                 arvalid,
    output wire                 arready,
    output wire [DATA_W-1:0]    rdata,
    output wire [1:0]           rresp,
    output wire                 rlast,
    output wire                 rvalid,
    input  wire                 rready,
    input  wire [ADDR_W-1:0]    awaddr,
    input  wire [7:0]           awlen,
    input  wire                 awvalid,
    output wire                 awready,
    input  wire [DATA_W-1:0]    wdata,
    input  wire                 wlast,
    input  wire                 wvalid,
    output wire                 wready,
    output wire [1:0]           bresp,
    output wire                 bvalid,
    input  wire                 bready
);
    localparam IDX_W = $clog2(MEM_WORDS);
    localparam BYTE_SH = $clog2(DATA_W/8);

    reg [DATA_W-1:0] mem [0:MEM_WORDS-1];

    reg [15:0] lfsr;
    wire [15:0] lfsr_n = {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
    wire [7:0]  jit    = (JITTER == 0) ? 8'd0 : (lfsr[7:0] % (JITTER + 1));

    localparam R_IDLE = 2'd0, R_WAIT = 2'd1, R_DATA = 2'd2;
    reg [1:0]        rst_s;
    reg [ADDR_W-1:0] raddr;
    reg [7:0]        rbeats, rcnt;

    assign arready = (rst_s == R_IDLE);
    assign rvalid  = (rst_s == R_DATA);
    assign rdata   = mem[raddr[IDX_W+BYTE_SH-1:BYTE_SH]];
    assign rresp   = 2'b00;
    assign rlast   = (rbeats == 0);

    localparam W_IDLE = 2'd0, W_DATA = 2'd1, W_WAIT = 2'd2, W_RESP = 2'd3;
    reg [1:0]        wst_s;
    reg [ADDR_W-1:0] waddr;
    reg [7:0]        wcnt;

    assign awready = (wst_s == W_IDLE);
    assign wready  = (wst_s == W_DATA);
    assign bvalid  = (wst_s == W_RESP);
    assign bresp   = 2'b00;

    always @(posedge clk) begin
        if (!rst_n) begin
            lfsr <= 16'hACE1; rst_s <= R_IDLE; wst_s <= W_IDLE;
            raddr <= 0; rbeats <= 0; rcnt <= 0; waddr <= 0; wcnt <= 0;
        end else begin
            lfsr <= lfsr_n;

            case (rst_s)
                R_IDLE: if (arvalid) begin
                    raddr  <= araddr;
                    rbeats <= arlen;
                    rcnt   <= RD_LAT + jit - 1;
                    rst_s  <= R_WAIT;
                end
                R_WAIT: begin
                    if (rcnt == 0) rst_s <= R_DATA; else rcnt <= rcnt - 1'b1;
                end
                R_DATA: if (rready) begin
                    raddr <= raddr + (DATA_W/8);
                    if (rbeats == 0) rst_s <= R_IDLE; else rbeats <= rbeats - 1'b1;
                end
                default: rst_s <= R_IDLE;
            endcase

            case (wst_s)
                W_IDLE: if (awvalid) begin
                    waddr <= awaddr;
                    wst_s <= W_DATA;
                end
                W_DATA: if (wvalid) begin
                    mem[waddr[IDX_W+BYTE_SH-1:BYTE_SH]] <= wdata;
                    waddr <= waddr + (DATA_W/8);
                    if (wlast) begin
                        wcnt  <= WR_LAT + jit - 1;
                        wst_s <= W_WAIT;
                    end
                end
                W_WAIT: begin
                    if (wcnt == 0) wst_s <= W_RESP; else wcnt <= wcnt - 1'b1;
                end
                W_RESP: if (bready) wst_s <= W_IDLE;
                default: wst_s <= W_IDLE;
            endcase
        end
    end
endmodule
