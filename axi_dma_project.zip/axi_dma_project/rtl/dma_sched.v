module dma_sched #(
    parameter N_CH     = 4,
    parameter S_SLOTS  = 8,
    parameter SLOT_LEN = 64,
    parameter MODE     = 0,
    parameter OWN_W    = 2
)(
    input  wire                      clk,
    input  wire                      rst_n,
    input  wire [N_CH-1:0]           req,
    input  wire [N_CH-1:0]           rel,
    input  wire [S_SLOTS*OWN_W-1:0]  slot_tbl,
    input  wire                      clr_status,
    output reg  [N_CH-1:0]           gnt,
    output reg                       overrun,
    output wire [$clog2(S_SLOTS)-1:0] slot_idx_o
);
    localparam SIDX_W = $clog2(S_SLOTS);
    localparam CNT_W  = $clog2(SLOT_LEN);

    wire [N_CH-1:0] gnt_live = gnt & ~rel;
    wire            held     = |gnt_live;

    generate
    if (MODE == 0) begin : g_tdma
        reg [CNT_W-1:0]  cnt;
        reg [SIDX_W-1:0] sidx;
        wire             at_end = (cnt == SLOT_LEN-1);
        wire [SIDX_W-1:0] nidx  = (sidx == S_SLOTS-1) ? {SIDX_W{1'b0}} : sidx + 1'b1;
        wire [OWN_W-1:0]  nown  = slot_tbl[nidx*OWN_W +: OWN_W];
        assign slot_idx_o = sidx;

        always @(posedge clk) begin
            if (!rst_n) begin
                cnt <= 0; sidx <= 0; gnt <= 0; overrun <= 1'b0;
            end else begin
                gnt <= gnt_live;
                if (clr_status) overrun <= 1'b0;
                if (at_end) begin
                    if (held) begin
                        overrun <= 1'b1;
                    end else begin
                        cnt  <= 0;
                        sidx <= nidx;
                        if (req[nown] && !rel[nown]) gnt <= ({{(N_CH-1){1'b0}}, 1'b1} << nown);
                    end
                end else begin
                    cnt <= cnt + 1'b1;
                end
            end
        end
    end else begin : g_work_conserving
        reg  [OWN_W-1:0] last;
        reg  [N_CH-1:0]  pick;
        reg              found;
        integer          k, idx;
        assign slot_idx_o = {SIDX_W{1'b0}};

        always @* begin
            pick  = {N_CH{1'b0}};
            found = 1'b0;
            if (MODE == 1) begin
                for (k = 1; k <= N_CH; k = k + 1) begin
                    idx = (last + k) % N_CH;
                    if (!found && req[idx]) begin pick[idx] = 1'b1; found = 1'b1; end
                end
            end else begin
                for (k = 0; k < N_CH; k = k + 1) begin
                    if (!found && req[k]) begin pick[k] = 1'b1; found = 1'b1; end
                end
            end
        end

        always @(posedge clk) begin
            if (!rst_n) begin
                gnt <= 0; last <= 0; overrun <= 1'b0;
            end else begin
                if (clr_status) overrun <= 1'b0;
                gnt <= gnt_live;
                if (gnt == 0 && found) begin
                    gnt <= pick;
                    for (k = 0; k < N_CH; k = k + 1) if (pick[k]) last <= k;
                end
            end
        end
    end
    endgenerate
endmodule
