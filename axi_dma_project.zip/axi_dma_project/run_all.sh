#!/bin/sh
cd "$(dirname "$0")"
./sim/run_icarus.sh
python3 scripts/analyze.py
