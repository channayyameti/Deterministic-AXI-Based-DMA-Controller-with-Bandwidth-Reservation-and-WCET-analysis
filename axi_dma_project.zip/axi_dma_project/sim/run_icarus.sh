#!/bin/sh
set -e
cd "$(dirname "$0")/.."
mkdir -p sim/logs
JIT=${JIT:-4}
for M in 0 1 2; do
  iverilog -g2012 -DMODE_VAL=$M -DJIT_VAL=$JIT -s tb_axi_dma -o sim/m${M}.vvp rtl/*.v tb/tb_axi_dma.sv
  vvp -n sim/m${M}.vvp > sim/logs/mode${M}.log
  grep -E "^(SUMMARY|FATAL|WARN)" sim/logs/mode${M}.log
done
iverilog -g2012 -DMODE_VAL=0 -DJIT_VAL=0 -s tb_axi_dma -o sim/m0_j0.vvp rtl/*.v tb/tb_axi_dma.sv
vvp -n sim/m0_j0.vvp > sim/logs/mode0_jit0.log
grep -E "^(SUMMARY|FATAL|WARN)" sim/logs/mode0_jit0.log
echo "logs written to sim/logs/"
