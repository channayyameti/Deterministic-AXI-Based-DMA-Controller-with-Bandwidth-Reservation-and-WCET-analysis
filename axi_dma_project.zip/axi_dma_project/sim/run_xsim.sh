#!/bin/sh
cd "$(dirname "$0")/.."
mkdir -p sim/logs sim/xsim_work
cd sim/xsim_work
SRC="../../rtl/axi_dma_ch.v ../../rtl/dma_sched.v ../../rtl/axi_dma_regs.v ../../rtl/axi_dma_top.v ../../rtl/axi_mem_model.v ../../tb/tb_axi_dma.sv"
for M in 0 1 2; do
  xvlog -sv -d MODE_VAL=$M -d JIT_VAL=4 $SRC
  xelab -debug typical -s sim_m$M tb_axi_dma
  xsim sim_m$M -runall > ../logs/mode$M.log
done
xvlog -sv -d MODE_VAL=0 -d JIT_VAL=0 $SRC
xelab -debug typical -s sim_m0_j0 tb_axi_dma
xsim sim_m0_j0 -runall > ../logs/mode0_jit0.log
cd ../..
python3 scripts/analyze.py
