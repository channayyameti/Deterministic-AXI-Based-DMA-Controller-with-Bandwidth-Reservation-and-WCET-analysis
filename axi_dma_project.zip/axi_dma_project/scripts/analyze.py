#!/usr/bin/env python3
import csv
import os
import sys
from collections import defaultdict

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOGS = os.path.join(ROOT, "sim", "logs")
OUT = os.path.join(ROOT, "results")
os.makedirs(OUT, exist_ok=True)

MODE_NAME = {0: "TDMA (reserved)", 1: "Round-robin", 2: "Fixed-priority"}
DEFAULT_TBL = [0, 1, 0, 2, 0, 1, 0, 3]
REQ_OFFSET = 2
BURST_BYTES = 64


def parse(path):
    d = defaultdict(list)
    cfg = {}
    if not os.path.exists(path):
        return d, cfg
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or "," not in line:
                continue
            parts = line.split(",")
            tag = parts[0]
            if tag == "CFG":
                cfg[parts[1]] = int(parts[2])
            elif tag in ("BW", "UTIL", "LAT", "SAMP", "SVC", "CHECK", "SUMMARY", "BOUND", "ISO", "FUNC", "STATUS", "SIM_DONE"):
                d[tag].append(parts[1:])
    return d, cfg


def next_start(starts, frame, t):
    k, off = divmod(t, frame)
    for s in starts:
        if s >= off:
            return k * frame + s
    return (k + 1) * frame + starts[0]


def tdma_wcet(tbl, slot_len, ch, n, r_rel_max):
    s_cnt = len(tbl)
    frame = s_cnt * slot_len
    starts = [s * slot_len for s in range(s_cnt) if tbl[s] == ch]
    worst = 0
    best = 1 << 30
    for t0 in range(frame):
        t = t0 + REQ_OFFSET
        rel = 0
        for _ in range(n):
            b = next_start(starts, frame, t)
            rel = b + r_rel_max
            t = rel + 2
        lat = rel + 1 - t0
        worst = max(worst, lat)
        best = min(best, lat)
    return worst, best


def rr_estimate(n_ch, n, r_rel_max):
    return n * n_ch * (r_rel_max + 2) + 6


def pct(x, tot):
    return 100.0 * x / tot if tot else 0.0


def main():
    logs = {
        "tdma": parse(os.path.join(LOGS, "mode0.log")),
        "rr": parse(os.path.join(LOGS, "mode1.log")),
        "fp": parse(os.path.join(LOGS, "mode2.log")),
        "tdma0": parse(os.path.join(LOGS, "mode0_jit0.log")),
    }
    if not logs["tdma"][0]:
        print("no logs found in", LOGS)
        sys.exit(1)

    cfg = logs["tdma"][1]
    n_ch = cfg["N_CH"]
    slot_len = cfg["SLOT_LEN"]
    frame = cfg["FRAME"]
    r_rel = cfg["R_REL_MAX"]
    jit = cfg["JITTER"]
    clk_ns = cfg.get("CLK_NS", 10)
    mhz = 1000.0 / clk_ns

    md = []
    md.append("# Results: deterministic AXI DMA (simulation, Icarus Verilog)\n")
    md.append("All numbers below come from the self-checking testbench logs in `sim/logs/`. Timing numbers here are **cycle counts in simulation**; post-implementation timing (WNS, Fmax) must come from your own Vivado run.\n")

    md.append("## 1. Configuration\n")
    md.append("| Parameter | Value |\n|---|---|")
    for k in ["N_CH", "S_SLOTS", "SLOT_LEN", "BURST_LEN", "DATA_W", "RD_LAT", "WR_LAT", "JITTER", "FRAME", "R_REL_MAX"]:
        md.append(f"| {k} | {cfg[k]} |")
    md.append(f"| Default slot table (slot0..7 owner) | {DEFAULT_TBL} |")
    md.append(f"| Clock assumed for MB/s | {mhz:.0f} MHz |\n")

    md.append("## 2. Bandwidth reservation under saturation (all 4 channels streaming, 20000-cycle window)\n")
    md.append("| Scheduler | ch0 | ch1 | ch2 | ch3 | Total bursts | Bus held (grant cycles) | Copy throughput |\n|---|---|---|---|---|---|---|---|")
    bw_rows = []
    for key, mode in (("tdma", 0), ("rr", 1), ("fp", 2)):
        d = logs[key][0]
        rows = [r for r in d["BW"] if r[0] == "def"]
        cnt = [int(r[3]) for r in rows]
        win = int(rows[0][4])
        tot = sum(cnt)
        util = [r for r in d["UTIL"] if r[0] == "def"][0]
        held = int(util[2])
        bpc = tot * BURST_BYTES / win
        cells = " | ".join(f"{c} ({pct(c, tot):.1f}%)" for c in cnt)
        md.append(f"| {MODE_NAME[mode]} | {cells} | {tot} | {pct(held, win):.1f}% | {bpc:.2f} B/cycle = {bpc * mhz:.0f} MB/s |")
        bw_rows.append((MODE_NAME[mode], cnt, tot, held, win))
    d = logs["tdma"][0]
    alt = [r for r in d["BW"] if r[0] == "alt"]
    cnt = [int(r[3]) for r in alt]
    tot = sum(cnt)
    md.append("")
    md.append(f"Runtime reprogramming of the TDMA slot table (alt table [0,0,1,0,2,0,3,0]): " + ", ".join(f"ch{i}={c} ({pct(c, tot):.1f}%)" for i, c in enumerate(cnt)) + ".\n")

    md.append("## 3. Victim channel (ch3, 1-burst descriptor) latency, cycles start-to-done\n")
    md.append("Swept over all start phases of the frame. 'Idle' = other channels quiet, 'Loaded' = other 3 channels saturating.\n")
    md.append("| Scheduler | Idle min | Idle max | Loaded min | Loaded max | Loaded mean | Max(loaded) / Max(idle) | Analytic bound |\n|---|---|---|---|---|---|---|---|")
    exact3, _ = tdma_wcet(DEFAULT_TBL, slot_len, 3, 1, r_rel)
    lat_rows = {}
    for key, mode in (("tdma", 0), ("rr", 1), ("fp", 2)):
        d = logs[key][0]
        a = [r for r in d["LAT"] if r[1] == "A" and r[2] == "3"][0]
        b = [r for r in d["LAT"] if r[1] == "B" and r[2] == "3"][0]
        amin, amax, bst = int(a[5]), int(a[6]), int(b[8])
        bmin, bmax = int(b[5]), int(b[6])
        bmean = (int(b[7]) / int(b[4])) if int(b[4]) else 0
        if bst:
            md.append(f"| {MODE_NAME[mode]} | {amin} | {amax} | STARVED | STARVED | - | unbounded | none |")
        else:
            bound = f"{exact3} (exact)" if mode == 0 else f"~{rr_estimate(n_ch, 1, r_rel)} (estimate)"
            md.append(f"| {MODE_NAME[mode]} | {amin} | {amax} | {bmin} | {bmax} | {bmean:.1f} | {bmax / amax:.2f} | {bound} |")
        lat_rows[key] = (amin, amax, bmin, bmax, bst)
    md.append("")

    md.append("## 4. WCET: analytic bound vs measured (TDMA, all channels loaded by the other three)\n")
    md.append("Analytic bound = exact enumeration over every start phase, using the worst-case burst service time from the RTL FSM timing. Measured = testbench sweep with the LFSR-jittered memory model (jitter 0..%d cycles on read and write response)." % jit)
    md.append("`Measured (jitter 0)` is a second run with zero jitter, where the bound for n=1 must be matched exactly if the analysis is right.\n")
    md.append("| Channel | Slots/frame | Bursts n | Measured max (jitter %d) | Measured max (jitter 0) | Analytic exact (jitter %d) | Analytic exact (jitter 0) | Slack (cycles) | Bound held |\n|---|---|---|---|---|---|---|---|---|" % (jit, jit))
    wc_rows = []
    d = logs["tdma"][0]
    d0 = logs["tdma0"][0]
    r_rel0 = r_rel - 2 * jit
    for ch in range(n_ch):
        for nb in (1, 4):
            tag = "C" if nb == 1 else "D"
            m = [r for r in d["LAT"] if r[1] == tag and r[2] == str(ch)][0]
            meas = int(m[6])
            m0 = [r for r in d0["LAT"] if r[1] == tag and r[2] == str(ch)]
            meas0 = int(m0[0][6]) if m0 else -1
            ex, _ = tdma_wcet(DEFAULT_TBL, slot_len, ch, nb, r_rel)
            ex0, _ = tdma_wcet(DEFAULT_TBL, slot_len, ch, nb, r_rel0)
            slots = DEFAULT_TBL.count(ch)
            ok = "yes" if meas <= ex and meas0 <= ex0 else "NO"
            md.append(f"| ch{ch} | {slots} | {nb} | {meas} | {meas0} | {ex} | {ex0} | {ex - meas} | {ok} |")
            wc_rows.append((ch, nb, meas, meas0, ex, ex0))
    a0 = [r for r in d0["LAT"] if r[1] == "A" and r[2] == "3"]
    if a0:
        md.append("")
        md.append(f"Full 512-phase sweep, ch3, 1 burst, jitter 0: measured max = {a0[0][6]}, analytic exact = {tdma_wcet(DEFAULT_TBL, slot_len, 3, 1, r_rel0)[0]}.\n")

    md.append("## 5. Self-checks in the testbench\n")
    md.append("| Run | Checks passed | Checks failed |\n|---|---|---|")
    for key, name in (("tdma", "TDMA, jitter %d" % jit), ("rr", "Round-robin, jitter %d" % jit), ("fp", "Fixed-priority, jitter %d" % jit), ("tdma0", "TDMA, jitter 0")):
        s = logs[key][0]["SUMMARY"]
        if s:
            md.append(f"| {name} | {s[0][2]} | {s[0][3]} |")
    fails = [(k, r) for k, v in logs.items() for r in v[0]["CHECK"] if r[1] == "FAIL"]
    md.append("")
    md.append("Failing checks: " + (", ".join(f"{k}:{r[0]}" for k, r in fails) if fails else "none") + "\n")
    sv = logs["tdma"][0]["SVC"][0]
    md.append(f"Measured per-burst bus-hold time (TDMA, jitter {jit}): min {sv[1]}, max {sv[2]} cycles; slot length {slot_len}; analytic worst case {sv[3]}.\n")

    md.append("## 6. Comparison summary (for the presentation)\n")
    t = lat_rows["tdma"]
    r = lat_rows["rr"]
    md.append("| Property | TDMA + reservation (this work) | Round-robin baseline | Fixed-priority baseline |\n|---|---|---|---|")
    md.append(f"| Guaranteed bandwidth share | Yes, set by slot table (50/25/12.5/12.5 % measured) | No, equal split only | No, starvation of low priority |")
    md.append(f"| Victim ch3 max latency idle vs loaded | {t[1]} vs {t[3]} cycles (isolated) | {r[1]} vs {r[3]} cycles (load-dependent) | starved when ch0 saturates |")
    md.append(f"| Latency bound | Exact, independent of other channels | Estimate depends on every other channel's burst time | None |")
    tb = bw_rows[0]
    rb = bw_rows[1]
    md.append(f"| Bus held (saturated) | {pct(tb[3], tb[4]):.1f}% | {pct(rb[3], rb[4]):.1f}% | {pct(bw_rows[2][3], bw_rows[2][4]):.1f}% |")
    md.append(f"| Cost | Idle slot time is not reclaimed, lower peak throughput | Best throughput | Best for one favoured master only |\n")
    md.append("Honest reading: for a single lightly-loaded victim, round-robin has a *lower* worst-case latency than the TDMA frame (about %d vs %d cycles for ch3). TDMA's advantage is the guaranteed share and that the bound does not move when other masters change behaviour.\n" % (rr_estimate(n_ch, 1, r_rel), exact3))

    with open(os.path.join(OUT, "summary.md"), "w") as f:
        f.write("\n".join(md) + "\n")

    with open(os.path.join(OUT, "wcet_table.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["channel", "bursts", "measured_max_jit", "measured_max_jit0", "analytic_exact_jit", "analytic_exact_jit0"])
        w.writerows(wc_rows)
    with open(os.path.join(OUT, "bandwidth.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["scheduler", "ch0", "ch1", "ch2", "ch3", "total", "grant_cycles", "window"])
        for name, cnt, tot, held, win in bw_rows:
            w.writerow([name] + cnt + [tot, held, win])

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as e:
        print("matplotlib unavailable, skipping plots:", e)
        return

    fig, ax = plt.subplots(figsize=(8, 4.5))
    width = 0.25
    for j, (name, cnt, tot, held, win) in enumerate(bw_rows):
        xs = [i + (j - 1) * width for i in range(n_ch)]
        ax.bar(xs, [pct(c, tot) for c in cnt], width, label=name)
    ax.set_xticks(range(n_ch))
    ax.set_xticklabels([f"ch{i}" for i in range(n_ch)])
    ax.set_ylabel("Share of completed bursts (%)")
    ax.set_title("Bandwidth share under saturation")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "bandwidth_share.png"), dpi=200)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4.5))
    styles = {("tdma", "A"): ("TDMA idle", "-"), ("tdma", "B"): ("TDMA loaded", "--"),
              ("rr", "A"): ("RR idle", "-"), ("rr", "B"): ("RR loaded", "--")}
    for (key, tag), (label, ls) in styles.items():
        vals = sorted(int(r[5]) for r in logs[key][0]["SAMP"] if r[1] == tag and r[2] == "3" and r[3] == "1")
        if not vals:
            continue
        ys = [(i + 1) / len(vals) for i in range(len(vals))]
        ax.step(vals, ys, where="post", linestyle=ls, label=label)
    ax.axvline(exact3, color="k", linestyle=":", label=f"TDMA exact bound {exact3}")
    ax.set_xlabel("Start-to-done latency (cycles)")
    ax.set_ylabel("Cumulative fraction")
    ax.set_title("Victim ch3, 1 burst (fixed-priority starves, not plotted)")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "victim_latency_cdf.png"), dpi=200)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 4.5))
    labels = [f"ch{c}\nn={n}" for c, n, *_ in wc_rows]
    xs = list(range(len(wc_rows)))
    ax.bar([x - 0.2 for x in xs], [r[2] for r in wc_rows], 0.4, label="Measured max (sim)")
    ax.bar([x + 0.2 for x in xs], [r[4] for r in wc_rows], 0.4, label="Analytic WCET bound")
    ax.set_xticks(xs)
    ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel("Cycles")
    ax.set_title("TDMA descriptor latency: measured vs analytic WCET")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "wcet_vs_measured.png"), dpi=200)
    plt.close(fig)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
