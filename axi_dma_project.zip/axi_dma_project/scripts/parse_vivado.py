#!/usr/bin/env python3
import csv
import os
import re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BUILD = os.path.join(ROOT, "build")
OUT = os.path.join(ROOT, "results")
os.makedirs(OUT, exist_ok=True)
NAMES = {0: "TDMA (reserved)", 1: "Round-robin", 2: "Fixed-priority"}


def first(pattern, text, group=1):
    m = re.search(pattern, text, re.M)
    return m.group(group).strip() if m else "n/a"


def util(text):
    return {
        "LUT": first(r"^\|\s*(?:Slice|CLB) LUTs\*?\s*\|\s*(\d+)", text),
        "LUT as RAM": first(r"^\|\s*LUT as Distributed RAM\s*\|\s*(\d+)", text),
        "FF": first(r"^\|\s*(?:Slice|CLB) Registers\s*\|\s*(\d+)", text),
        "BRAM": first(r"^\|\s*Block RAM Tile\s*\|\s*([\d.]+)", text),
        "DSP": first(r"^\|\s*DSPs\s*\|\s*(\d+)", text),
    }


def main():
    rows = []
    for mode in (0, 1, 2):
        d = os.path.join(BUILD, f"mode{mode}")
        if not os.path.isdir(d):
            continue
        row = {"mode": NAMES[mode]}
        sc = os.path.join(d, "summary.csv")
        if os.path.exists(sc):
            with open(sc) as f:
                r = list(csv.DictReader(f))[0]
            row.update({"part": r["part"], "period": r["period_ns"], "WNS": r["wns_ns"], "WHS": r["whs_ns"]})
            try:
                row["Fmax"] = "%.1f" % (1000.0 / (float(r["period_ns"]) - float(r["wns_ns"])))
            except ValueError:
                row["Fmax"] = "n/a"
        up = os.path.join(d, "utilization.rpt")
        if os.path.exists(up):
            row.update(util(open(up).read()))
        pp = os.path.join(d, "power.rpt")
        if os.path.exists(pp):
            row["Power W"] = first(r"Total On-Chip Power \(W\)\s*\|\s*([\d.]+)", open(pp).read())
        rows.append(row)
    if not rows:
        print("no Vivado results in", BUILD)
        return
    cols = ["mode", "part", "period", "WNS", "WHS", "Fmax", "LUT", "LUT as RAM", "FF", "BRAM", "DSP", "Power W"]
    lines = ["# Vivado implementation summary (out-of-context, post-route)\n",
             "Fmax = 1000 / (period - WNS), in MHz, valid only when timing was constrained as in `vivado/run_impl.tcl`.\n",
             "| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for r in rows:
        lines.append("| " + " | ".join(str(r.get(c, "n/a")) for c in cols) + " |")
    with open(os.path.join(OUT, "vivado_summary.md"), "w") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
