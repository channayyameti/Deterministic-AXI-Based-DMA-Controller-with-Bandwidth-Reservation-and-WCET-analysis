#!/usr/bin/env python3
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "eda_playground")
os.makedirs(OUT, exist_ok=True)

files = ["axi_dma_ch.v", "dma_sched.v", "axi_dma_regs.v", "axi_dma_top.v", "axi_mem_model.v"]
with open(os.path.join(OUT, "design.sv"), "w") as o:
    for f in files:
        o.write(open(os.path.join(ROOT, "rtl", f)).read() + "\n")

tb = open(os.path.join(ROOT, "tb", "tb_axi_dma.sv")).read()
tb = tb.replace("`define MODE_VAL 0", "`define MODE_VAL 0", 1)
tb = tb.replace("`define SWEEP_N 512", "`define SWEEP_N 128", 1)
tb = tb.replace("`define BW_WIN 20000", "`define BW_WIN 8000", 1)
tb = tb.replace("`define T4_N 96", "`define T4_N 16", 1)
with open(os.path.join(OUT, "testbench.sv"), "w") as o:
    o.write(tb)
print("wrote", OUT)
