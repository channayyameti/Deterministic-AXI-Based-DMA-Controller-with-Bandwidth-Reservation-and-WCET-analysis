# Results: deterministic AXI DMA (simulation, Icarus Verilog)

All numbers below come from the self-checking testbench logs in `sim/logs/`. Timing numbers here are **cycle counts in simulation**; post-implementation timing (WNS, Fmax) must come from your own Vivado run.

## 1. Configuration

| Parameter | Value |
|---|---|
| N_CH | 4 |
| S_SLOTS | 8 |
| SLOT_LEN | 64 |
| BURST_LEN | 16 |
| DATA_W | 32 |
| RD_LAT | 8 |
| WR_LAT | 4 |
| JITTER | 4 |
| FRAME | 512 |
| R_REL_MAX | 55 |
| Default slot table (slot0..7 owner) | [0, 1, 0, 2, 0, 1, 0, 3] |
| Clock assumed for MB/s | 100 MHz |

## 2. Bandwidth reservation under saturation (all 4 channels streaming, 20000-cycle window)

| Scheduler | ch0 | ch1 | ch2 | ch3 | Total bursts | Bus held (grant cycles) | Copy throughput |
|---|---|---|---|---|---|---|---|
| TDMA (reserved) | 156 (49.8%) | 79 (25.2%) | 39 (12.5%) | 39 (12.5%) | 313 | 80.8% | 1.00 B/cycle = 100 MB/s |
| Round-robin | 95 (25.1%) | 95 (25.1%) | 94 (24.9%) | 94 (24.9%) | 378 | 98.1% | 1.21 B/cycle = 121 MB/s |
| Fixed-priority | 378 (100.0%) | 0 (0.0%) | 0 (0.0%) | 0 (0.0%) | 378 | 98.1% | 1.21 B/cycle = 121 MB/s |

Runtime reprogramming of the TDMA slot table (alt table [0,0,1,0,2,0,3,0]): ch0=196 (62.6%), ch1=39 (12.5%), ch2=39 (12.5%), ch3=39 (12.5%).

## 3. Victim channel (ch3, 1-burst descriptor) latency, cycles start-to-done

Swept over all start phases of the frame. 'Idle' = other channels quiet, 'Loaded' = other 3 channels saturating.

| Scheduler | Idle min | Idle max | Loaded min | Loaded max | Loaded mean | Max(loaded) / Max(idle) | Analytic bound |
|---|---|---|---|---|---|---|---|
| TDMA (reserved) | 53 | 563 | 55 | 565 | 310.9 | 1.00 | 569 (exact) |
| Round-robin | 50 | 58 | 54 | 220 | 136.5 | 3.79 | ~234 (estimate) |
| Fixed-priority | 50 | 58 | STARVED | STARVED | - | unbounded | none |

## 4. WCET: analytic bound vs measured (TDMA, all channels loaded by the other three)

Analytic bound = exact enumeration over every start phase, using the worst-case burst service time from the RTL FSM timing. Measured = testbench sweep with the LFSR-jittered memory model (jitter 0..4 cycles on read and write response).
`Measured (jitter 0)` is a second run with zero jitter, where the bound for n=1 must be matched exactly if the analysis is right.

| Channel | Slots/frame | Bursts n | Measured max (jitter 4) | Measured max (jitter 0) | Analytic exact (jitter 4) | Analytic exact (jitter 0) | Slack (cycles) | Bound held |
|---|---|---|---|---|---|---|---|---|
| ch0 | 4 | 1 | 181 | 176 | 185 | 177 | 4 | yes |
| ch0 | 4 | 4 | 566 | 560 | 569 | 561 | 3 | yes |
| ch1 | 2 | 1 | 305 | 303 | 313 | 305 | 8 | yes |
| ch1 | 2 | 4 | 1072 | 1071 | 1081 | 1073 | 9 | yes |
| ch2 | 1 | 1 | 553 | 559 | 569 | 561 | 16 | yes |
| ch2 | 1 | 4 | 2098 | 2095 | 2105 | 2097 | 7 | yes |
| ch3 | 1 | 1 | 557 | 559 | 569 | 561 | 12 | yes |
| ch3 | 1 | 4 | 2102 | 2095 | 2105 | 2097 | 3 | yes |

Full 512-phase sweep, ch3, 1 burst, jitter 0: measured max = 561, analytic exact = 561.

## 5. Self-checks in the testbench

| Run | Checks passed | Checks failed |
|---|---|---|
| TDMA, jitter 4 | 19 | 0 |
| Round-robin, jitter 4 | 8 | 0 |
| Fixed-priority, jitter 4 | 8 | 0 |
| TDMA, jitter 0 | 19 | 0 |

Failing checks: none

Measured per-burst bus-hold time (TDMA, jitter 4): min 48, max 56 cycles; slot length 64; analytic worst case 56.

## 6. Comparison summary (for the presentation)

| Property | TDMA + reservation (this work) | Round-robin baseline | Fixed-priority baseline |
|---|---|---|---|
| Guaranteed bandwidth share | Yes, set by slot table (50/25/12.5/12.5 % measured) | No, equal split only | No, starvation of low priority |
| Victim ch3 max latency idle vs loaded | 563 vs 565 cycles (isolated) | 58 vs 220 cycles (load-dependent) | starved when ch0 saturates |
| Latency bound | Exact, independent of other channels | Estimate depends on every other channel's burst time | None |
| Bus held (saturated) | 80.8% | 98.1% | 98.1% |
| Cost | Idle slot time is not reclaimed, lower peak throughput | Best throughput | Best for one favoured master only |

Honest reading: for a single lightly-loaded victim, round-robin has a *lower* worst-case latency than the TDMA frame (about 234 vs 569 cycles for ch3). TDMA's advantage is the guaranteed share and that the bound does not move when other masters change behaviour.

